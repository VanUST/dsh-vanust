/**
 * Runtime loader for the vendored xterm.js asset, served by the host bridge
 * at `/wb-api/static/xterm.js` (+ its stylesheet). The UMD bundle attaches
 * `Terminal` to the window global; the loader fetches it once and exposes a
 * typed facade over the surface this package uses.
 * @module @deepseek-ai/dsh-client-ui-terminal/client/xterm-loader
 */
/** Options accepted by the Terminal constructor. */
export interface XTerminalOptions {
    cols?: number;
    rows?: number;
    scrollback?: number;
    fontSize?: number;
    fontFamily?: string;
    theme?: Record<string, string>;
    cursorBlink?: boolean;
    convertEol?: boolean;
}
/** Disposer returned by event registrations. */
export interface XTerminalDisposable {
    dispose(): void;
}
/** Terminal resize event payload. */
export interface XTerminalResizeEvent {
    cols: number;
    rows: number;
}
/** Terminal exit event payload. */
export interface XTerminalExitEvent {
    exitCode: number;
}
/** The terminal emulator surface used by the panel. */
export interface XTerminal {
    readonly cols: number;
    readonly rows: number;
    open(parent: HTMLElement): void;
    write(data: string): void;
    resize(cols: number, rows: number): void;
    dispose(): void;
    focus(): void;
    onData(cb: (data: string) => void): XTerminalDisposable;
    onResize(cb: (event: XTerminalResizeEvent) => void): XTerminalDisposable;
    onExit(cb: (event: XTerminalExitEvent) => void): XTerminalDisposable;
}
/** Constructor face of the xterm Terminal class. */
export interface XTerminalConstructor {
    new (options?: XTerminalOptions): XTerminal;
}
/**
 * Compute the terminal size that fills a container, using a hidden font probe
 * with the exact same face the terminal was constructed with. The vendored
 * xterm bundle has NO auto-fit (no ResizeObserver, no window listener — that
 * is the @xterm/addon-fit job, which we deliberately do not vendor), so the
 * caller must fit explicitly after open and on container changes.
 * @param container - the element the terminal was opened in.
 * @param fontSize - terminal font size in px (must match the constructor).
 * @param fontFamily - terminal font family (must match the constructor).
 * @returns the fitted cell grid; a 15px scrollbar reserve is subtracted.
 */
export declare function fitTerminal(container: HTMLElement, fontSize: number, fontFamily: string): {
    cols: number;
    rows: number;
};
/**
 * Load the xterm script (once) and return the Terminal constructor.
 * @returns the Terminal constructor.
 * @throws when the asset fails to load.
 */
export declare function loadXterm(): Promise<XTerminalConstructor>;
/** Inject the vendored xterm stylesheet link once. */
export declare function ensureXtermCss(): void;
//# sourceMappingURL=xterm-loader.d.ts.map