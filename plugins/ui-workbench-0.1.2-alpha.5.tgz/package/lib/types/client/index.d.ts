/**
 * Workbench plugin, browser half: one `conversation.session.header.utilities`
 * entry rendering the in-flow toggle and the floating Files/Review/Browser
 * workbench. The occupant reads the standard session/workspace kit and the
 * /wb-api wire; it owns no domain store.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type WorkbenchKey } from '../locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Workbench tab and toggle copy. */
        workbench: WorkbenchKey;
    }
}
export type { WorkbenchHostProps, WorkbenchTab } from './WorkbenchHost.tsx';
export type { FilesTabProps } from './FilesTab.tsx';
export type { ReviewTabProps } from './ReviewTab.tsx';
export type { BrowserTabProps } from './BrowserTab.tsx';
export { TERMINAL_OPEN_EVENT, dispatchTerminalOpen, type TerminalOpenDetail } from './terminal-open.ts';
export { EDITOR_OPEN_EVENT, dispatchEditorOpen, type EditorOpenDetail } from './editor-open.ts';
/** Required services for locale registration and the header contribution. */
export declare const inject: string[];
/**
 * Client plugin body: register the dictionaries and the workbench header
 * toggle (which renders the floating panel). Registration rides the slot
 * service's effect wrapper, so plugin unload removes every surface.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map