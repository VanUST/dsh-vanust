# @cc/dsh-context

Three project-context tools for any repository on this harness. The project describes itself in
`.dsh/project.json`; nothing here assumes a language, a package manager or a test runner.

| Tool | Answers |
| --- | --- |
| `context_module` | which module owns a path, what it exports, what graph nodes it links to |
| `context_rules` | which rules this project claims, and the command that fails when one is broken |
| `context_specs` | what work is in flight, which paths it claims, and where scopes overlap |

## Why tools rather than documents

Agents grep; they do not reliably read prose. Exposing this as tools puts the cheap path and the
correct path in the same place, which is the only way a convention survives contact with an agent.
A documentation server is ignored almost always and a prose file about half the time; a tool is
called.

## Why it is project-agnostic

Rules are not language-specific, but the evidence for them always is: Python cites `pytest`, C/C++
cites `ctest`, Unity cites `dotnet test`. The manifest declares the toolchain, the languages and how
exactly each can be analysed, and the scopes a work order may cite. Adding a stack means adding a
manifest entry, not editing this plugin.

## Install

```bash
dsh plugin --profile web add file:/path/to/cc-dsh-context-0.1.0.tgz
```

then wire it in the profile's `cordis.patch.yml`:

```yaml
- insert:
    - id: dsh-context
      name: '@cc/dsh-context'
```

Adding a plugin to a profile requires a profile reload, which restarts the harness.
