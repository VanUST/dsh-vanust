/**
 * Terminal dictionary. The key union is derived from the Chinese dictionary
 * (`keyof typeof zh`), matching the stock client locale pattern; every
 * consumer types its `t` against it.
 * @module @deepseek-ai/dsh-client-ui-terminal/src/locales
 */
/** Chinese dictionary — the key source. */
export declare const zh: {
    readonly 'terminal.toggle': "终端";
    readonly 'terminal.close': "关闭终端";
    readonly 'terminal.opening': "正在打开 shell…";
    readonly 'terminal.ready': "已连接";
    readonly 'terminal.closed': "会话已退出";
    readonly 'terminal.full': "已达会话上限";
    readonly 'terminal.shellUnavailable': "Shell 可执行文件不可用";
    readonly 'terminal.failed': "终端失败";
    readonly 'terminal.reopen': "重新打开";
    readonly 'terminal.yazi': "yazi 文件管理器";
    readonly 'terminal.resize': "拖动调整终端高度";
};
/** Message keys of the terminal plugin. */
export type TerminalKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<TerminalKey, string>;
/** Namespace id of the terminal dictionaries. */
export declare const NS = "terminal";
//# sourceMappingURL=locales.d.ts.map