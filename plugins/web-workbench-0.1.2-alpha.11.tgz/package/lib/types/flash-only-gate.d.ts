/**
 * Deployment model-cost gate for the DeepSeek official route.
 *
 * Watches the `llm/stream` waterfall (the single chokepoint every model
 * dispatch passes: root turns, subagents, compaction, session titles) and
 * vetoes requests whose `model` matches no allowed exact id and no allowed
 * pattern. The veto throws *before* the waterfall's base `next()` runs, so the
 * adapter is never invoked and nothing is dispatched or billed.
 *
 * The policy is expressed by model CLASS, not by release version: the shipped
 * default allows every DeepSeek Flash id (current and future, e.g.
 * `deepseek-flash`, `deepseek-v4-flash`, `deepseek-v5.1-flash-vision`) and
 * therefore never needs editing when a new Flash version ships. Non-Flash
 * tiers (such as the pro line) match nothing and stay blocked.
 *
 * The gate is opt-in (`enabled: true`) so the plugin stays neutral for
 * adopters that do not want it; the dsh-kit deployment profile enables it.
 *
 * @module @deepseek-ai/dsh-host-web-workbench/flash-only-gate
 */
import type { Context } from '@deepseek-ai/cordis';
/**
 * Default allowlist pattern: any DeepSeek Flash-class model id, with an
 * optional version segment (`deepseek-flash`, `deepseek-v4-flash`,
 * `deepseek-v4-flash-vision-exp`, `deepseek-v5.1-flash`, …). Ids that name a
 * non-Flash tier (`deepseek-v4-pro`) deliberately do not match.
 */
export declare const FLASH_CLASS_DEFAULT_PATTERN = "^deepseek-(v[0-9.]+-)?flash(-[a-z0-9-]+)*$";
/** Default exact ids kept for readability of the composed policy. */
export declare const FLASH_ONLY_DEFAULT_MODELS: readonly string[];
/** Default patterns applied when no matcher is configured. */
export declare const FLASH_ONLY_DEFAULT_PATTERNS: readonly string[];
/** Stable failure code carried by every vetoed request. */
export declare const FLASH_ONLY_ERROR_CODE = "MODEL_NOT_ALLOWED";
/** Deployment configuration of the gate. */
export interface FlashOnlyGateConfig {
    /** Whether the gate is active. @default false */
    enabled?: boolean;
    /** Exact model ids allowed to reach the adapter. @default [] */
    allowedModels?: string[];
    /**
     * Model-id patterns (regular expressions, matched against the whole id)
     * allowed to reach the adapter. @default FLASH_ONLY_DEFAULT_PATTERNS
     */
    allowedModelPatterns?: string[];
}
/**
 * Install the gate on one context.
 * @param ctx - Cordis context whose `llm/stream` dispatches are gated.
 * @param config - deployment configuration.
 * @returns a disposer, or `undefined` when the gate is disabled.
 * @throws when enabled with no usable matcher (misconfiguration fails loud).
 */
export declare function installFlashOnlyGate(ctx: Context, config: FlashOnlyGateConfig): (() => void) | undefined;
//# sourceMappingURL=flash-only-gate.d.ts.map