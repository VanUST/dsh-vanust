/**
 * PURPOSE
 *   Keep delegated work on the cheap flash route. The harness default is already
 *   deepseek-flash, and the Subagent settings page can offer an allowlist, but
 *   neither refuses a workflow script that asks for deepseek-v4-pro: the request
 *   reaches the loop with whatever route the script named. This plugin sits on
 *   the `agent/request` waterfall, the last place the frozen LlmCallConfig can
 *   be replaced before dispatch, and REFUSES a child's disallowed route.
 *
 * INPUTS
 *   Config (all optional):
 *     provider / model       the fallback route. Default deepseek-official / deepseek-flash.
 *     allowedRoutes          exact {provider, model} pairs. Default: the fallback route.
 *     onViolation            only "refuse". Any other value (including the old default
 *                            "rewrite") is reported once and treated as "refuse", because dsh
 *                            freezes the route before `agent/request`: a rewritten call throws
 *                            inside the turn instead of redirecting it.
 *     enforceRoot            also apply to root agents. Default false, so the
 *                            human can still choose a stronger model for the
 *                            conversation itself.
 *     maxReasoningEffort     accepted for compatibility and IGNORED (see below).
 *     deniedModels           optional model-id patterns refused for EVERY agent,
 *                            root included. `*` matches any run of characters,
 *                            matching is case-insensitive, and the decision is a
 *                            refusal rather than a rewrite: silently substituting
 *                            another model is how a "never use this" rule gets
 *                            believed while the expensive route was paid for. A
 *                            pattern containing `/` matches `<provider>/<model>`.
 *
 * OUTPUTS
 *   One `agent/request` listener. It never registers a tool, prompt section,
 *   service or session event. A refusal throws before dispatch, so the child's
 *   turn fails with the guard's message instead of silently using another model.
 *
 * KEYWORDS
 *   flash, model guard, agent/request, delegated child, deepseek-flash, policy
 *
 * BEHAVIOUR ON EDGE CASES
 *   - A malformed allowedRoutes entry is dropped with a warning; an empty list
 *     falls back to the configured route rather than disabling the guard.
 *   - Any onViolation value other than "refuse" is treated as "refuse" and reported once:
 *     refusing every request because of a typo would be worse than the typo.
 *   - An agent without a session/header is left alone; the guard cannot prove it
 *     is a child, and a refusal it cannot attribute would break unrelated work.
 *   - A provider that does not route through DSH's LLM (ACP, SDK, Claude Code)
 *     never reaches `agent/request`; that is a documented residual, not a bug in
 *     this listener.
 *   - The warning is logged once per (agent, requested route), so a looping child
 *     does not fill the log with the same line.
 *   - A deniedModels entry that is not a non-empty string is dropped and counted;
 *     a typo never turns into "deny everything".
 *   - A denied-model refusal is reported once per denied pattern, not once per
 *     request, because it is a configuration fact rather than a looping child.
 *   - `maxReasoningEffort` no longer caps anything. Since dsh 0.2.2 the reasoning effort is part
 *     of the FROZEN step selection and is compared after `agent/request` exactly like the route
 *     (`dsh-agent-loop`: 'agent/request proposed reasoning effort "…" after step preparation fixed
 *     "…"'). Lowering it in this waterfall therefore threw the turn whenever the cap mattered —
 *     a guard that kills the work it was meant to make cheaper. The key is still accepted so an
 *     older profile boots, and its presence is reported once; a role that must not think that
 *     hard is routed with `agent.model.select()` (see `@cc/dsh-role-model`).
 */

/** Compile one deny pattern: `*` is the only metacharacter, matching is case-insensitive. */
function compileDenyPattern(pattern) {
  const source = pattern.trim().toLowerCase()
  const body = source
    .split('*')
    .map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
    .join('.*')
  return { source, matcher: new RegExp(`^${body}$`) }
}

/** Route of a request after the adapter has resolved it. */
const EFFORT_ORDER = ['off', 'low', 'high', 'max']

/**
 * Normalize the plugin config into a total policy.
 *
 * @param config - Raw Loader config.
 * @returns A policy that is safe for every request.
 */
export function normalizeConfig(config = {}) {
  const provider = typeof config.provider === 'string' && config.provider.trim() !== ''
    ? config.provider.trim()
    : 'deepseek-official'
  const model = typeof config.model === 'string' && config.model.trim() !== ''
    ? config.model.trim()
    : 'deepseek-flash'
  const fallback = { provider, model }
  const allowedRoutes = Array.isArray(config.allowedRoutes)
    ? config.allowedRoutes
      .filter((route) => route !== null && typeof route === 'object'
        && typeof route.provider === 'string' && route.provider !== ''
        && typeof route.model === 'string' && route.model !== '')
      .map((route) => ({ provider: route.provider, model: route.model }))
    : []
  // A rewrite is not an option on this harness any more (see the listener): the route is frozen
  // before dispatch, so the only enforcement left is a refusal, and every other value — including
  // the old default `rewrite` — is reported and treated as one.
  const onViolation = 'refuse'
  const denyCandidates = Array.isArray(config.deniedModels)
    ? config.deniedModels.filter((pattern) => typeof pattern === 'string' && pattern.trim() !== '')
    : []
  const deniedModels = denyCandidates.map(compileDenyPattern)
  return {
    fallback,
    allowedRoutes: allowedRoutes.length > 0 ? allowedRoutes : [fallback],
    deniedModels,
    onViolation,
    enforceRoot: config.enforceRoot === true,
    legacyEffortCap: config.maxReasoningEffort !== undefined,
    malformedOnViolation: config.onViolation !== undefined && config.onViolation !== 'refuse',
    droppedRoutes: Array.isArray(config.allowedRoutes) ? config.allowedRoutes.length - allowedRoutes.length : 0,
  }
}

/**
 * Decide what to do with one resolved call.
 *
 * @param call - The LlmCallConfig returned by `next()`.
 * @param agent - The requesting Agent.
 * @param policy - `normalizeConfig()` output.
 * @returns `{ action: 'allow' | 'refuse', call, reason?, denied? }` — a rewritten `call` is never
 *   produced: the harness freezes the route before this hook, and a mutation here throws.
 */
export function guardDecision(call, agent, policy) {
  const depth = Number(agent?.session?.header?.delegationDepth ?? 0)
  const parent = agent?.session?.header?.parentSession
  const isChild = (Number.isFinite(depth) && depth > 0) || (typeof parent === 'string' && parent.length > 0)
  const applies = isChild || policy.enforceRoot
  const key = `${call?.provider ?? ''}/${call?.model ?? ''}`
  const denied = denyMatch(call, policy.deniedModels)
  if (denied !== null) {
    return {
      action: 'refuse',
      call,
      denied: denied.source,
      reason: `flash-guard: ${key} matches deniedModels "${denied.source}" and is never dispatched; choose an allowed route`,
    }
  }
  const allowed = policy.allowedRoutes.some((route) => route.provider === call?.provider && route.model === call?.model)
  if (!applies) return { action: 'allow', call }
  if (!allowed) {
    // NEVER a rewrite: dsh freezes the route before `agent/request`, and a mutated result is a
    // thrown turn (see the listener). `capped` is not returned either — the effort is part of the
    // same frozen selection, so a refusal is the only honest answer.
    return {
      action: 'refuse',
      call,
      reason: `flash-guard: ${key} is not allowed for delegated work; use ${policy.fallback.provider}/${policy.fallback.model}`,
    }
  }
  return { action: 'allow', call }
}

/**
 * Find the first deny pattern a call matches.
 *
 * @param call - Resolved call.
 * @param deniedModels - Compiled deny patterns.
 * @returns The matching pattern, or null when nothing denies this call.
 */
function denyMatch(call, deniedModels) {
  if (deniedModels.length === 0 || call === null || typeof call !== 'object') return null
  const model = String(call.model ?? '').toLowerCase()
  const route = `${String(call.provider ?? '').toLowerCase()}/${model}`
  return deniedModels.find((pattern) => pattern.matcher.test(
    pattern.source.includes('/') ? route : model,
  )) ?? null
}

/** Cordis function-plugin name; also the id a profile patch targets. */
export const name = 'flash-guard'

/** Nothing is injected: the waterfall is global and needs no service. */
export const inject = []

/**
 * Register the request waterfall.
 *
 * @param ctx - Cordis context.
 * @param config - Raw plugin config.
 */
export function apply(ctx, config = {}) {
  const policy = normalizeConfig(config)
  if (policy.legacyEffortCap) {
    ctx.logger.warn('flash-guard: maxReasoningEffort is ignored — the reasoning effort is part of the frozen step selection, so capping it here would throw the turn; route the role explicitly instead')
  }
  if (policy.malformedOnViolation) {
    ctx.logger.warn(`flash-guard: onViolation ${JSON.stringify(config.onViolation)} is not "refuse"; using "refuse"`)
  }
  if (policy.droppedRoutes > 0) {
    ctx.logger.warn(`flash-guard: ignored ${policy.droppedRoutes} malformed allowedRoutes entr${policy.droppedRoutes === 1 ? 'y' : 'ies'}`)
  }
  const droppedDeny = (Array.isArray(config.deniedModels) ? config.deniedModels.length : 0) - policy.deniedModels.length
  if (droppedDeny > 0) {
    ctx.logger.warn(`flash-guard: ignored ${droppedDeny} malformed deniedModels entr${droppedDeny === 1 ? 'y' : 'ies'}`)
  }
  const warned = new Set()
  // THE ROUTE IS FIXED BEFORE THIS HOOK RUNS. dsh 0.2.2 rejects a rewritten route here:
  // `dsh-agent-loop` compares the waterfall's result with the step's frozen selection and
  // throws `agent/request proposed "…" after step preparation fixed "…"; use agent.model.select()
  // before step preparation`. A plugin that returns a different provider/model/effort is
  // therefore no longer steering the child, it is killing the turn — worse than the routing it
  // wanted to prevent, because the error lands mid-turn and after the task row was created.
  // So this listener never mutates: a violation is REFUSED with the rule and the allowed routes
  // named, which is the outcome the operator asked for anyway ("this child may not run there").
  ctx.on('agent/request', async (payload, next) => {
    const call = await next()
    const decision = guardDecision(call, payload?.agent, policy)
    if (decision.action === 'allow') return decision.call
    const agentId = payload?.agent?.id ?? 'unknown'
    // A deny rule is a configuration fact, so it is reported once per pattern;
    // an allowlist violation is reported once per agent and requested route.
    const key = decision.denied === undefined
      ? `${agentId}:${call?.provider ?? '?'}/${call?.model ?? '?'}`
      : `deny:${decision.denied}`
    if (!warned.has(key)) {
      warned.add(key)
      ctx.logger.warn(decision.reason)
    }
    throw new Error(`${decision.reason} (a route is fixed before dispatch on this harness: choose the route with agent.model.select()/the subagent model-selection allowlist, never by rewriting it here)`)
  })
}
