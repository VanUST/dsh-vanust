/**
 * Browser-facing workbench bridge (`ctx.webWorkbench`): workspace file
 * listing/reading, git review (changes/diff), real PTY terminal sessions over
 * WebSocket, and system file-manager integration for the web GUI's workbench
 * and terminal panels. Host side of the dsh-web-workbench plugin pair.
 *
 * Exposes plain HTTP + upgrade routes on the stock webserver (`/wb-api/*`) —
 * no typert descriptors, no gateway, no fork apiproxy: the browser fetches
 * JSON and opens one WebSocket per terminal session. Every file request
 * resolves through the workspace registry, so arbitrary paths are never
 * served. Terminal sessions allocate a real kernel PTY through `node-pty`
 * (the same PTY substrate VS Code, alacritty and kitty use) and bridge it to
 * the browser over the WebSocket — full-screen interactive programs work.
 * @module @deepseek-ai/dsh-host-web-workbench
 */
import { type ChildProcess, type SpawnOptions } from 'node:child_process';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type WebSocket } from 'ws';
import type { ChangedFileView, TerminalSessionView, WbApiErrorCode, WorkspaceFileListing, WorkspaceReadFile, WorkspaceReviewDiff } from './types.ts';
/** Plugin config of the workbench bridge. */
export interface WebWorkbenchConfig {
    /** Git executable to invoke; defaults to the `git` on PATH. */
    gitPath?: string;
    /** Byte cap for one diff response; longer diffs truncate with a marker. */
    diffMaxBytes?: number;
    /** Byte cap for one file-content response; longer files truncate. */
    readMaxBytes?: number;
    /** Entry cap for one recursive file listing; longer walks truncate. */
    listMaxEntries?: number;
    /** Kill a hung git invocation after this many milliseconds. */
    timeoutMs?: number;
    /** Shell executable for terminal sessions; defaults to `$SHELL`, `pwsh` on win32, else `bash`. */
    shell?: string;
    /** Fixed argument array passed to the shell (deployment-tunable). */
    args?: string[];
    /** Working directory for new terminal sessions; defaults to the host cwd. */
    cwd?: string;
    /** PTY type name (the TERM environment inside sessions). @default 'xterm-256color' */
    ptyName?: string;
    /** Maximum concurrent terminal sessions. */
    maxSessions?: number;
    /** Command that opens a path in the system file manager. @default 'xdg-open' */
    openCommand?: string;
    /** Optional TUI file manager offered by the Files tab (e.g. 'yazi'); auto-detected on PATH when unset, disabled when empty string. */
    tuiFileManager?: string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        webWorkbench: WebWorkbenchService;
    }
}
/** Typed rejection of a workbench operation. */
export declare class WebWorkbenchError extends Error {
    /** Stable machine-readable failure category. */
    readonly code: WbApiErrorCode;
    /**
     * @param code - stable machine-readable failure category.
     * @param message - human-readable failure detail.
     */
    constructor(code: WbApiErrorCode, message: string);
}
/** One finished git invocation. */
interface GitRun {
    stdout: Buffer;
    stderr: string;
    /** Process exit code; null only when the invocation could not start. */
    code: number | null;
    /** Whether the stdout byte cap cut the stream (the process was killed). */
    truncated: boolean;
}
/** One finished git invocation; a helper alias for tests. */
export interface GitInvocationResult extends GitRun {
}
/**
 * Browser-facing workbench bridge service.
 */
export declare class WebWorkbenchService extends Service {
    readonly config: WebWorkbenchConfig;
    static inject: string[];
    static Config: z<WebWorkbenchConfig>;
    private readonly sessions;
    private readonly wss;
    private readonly staticCache;
    /**
     * @param ctx - Cordis context (needs webServer + workspaceRegistry).
     * @param config - resolved bridge configuration.
     */
    constructor(ctx: Context, config: WebWorkbenchConfig);
    /** Register the /wb-api routes and the terminal WebSocket with the context. */
    [Service.init](): Promise<void>;
    /**
     * Serve one allowlisted browser asset (xterm.js / xterm.css). Assets are
     * read once and cached; unknown names 404.
     * @param name - asset file name.
     * @returns the cached asset, or undefined for unknown names.
     */
    private staticAsset;
    /**
     * Recursively list the files and directories of one registered workspace.
     * The walk skips every `.git` directory, emits directories before files at
     * each level, and stops at the configured entry cap.
     * @param workspaceId - registered workspace to inspect.
     * @returns the bounded file listing.
     * @throws {@link WebWorkbenchError} for unknown workspaces and filesystem
     * read failures.
     */
    listFiles(workspaceId: string): Promise<WorkspaceFileListing>;
    /**
     * Read the bounded UTF-8 content of one file inside a registered workspace.
     * The path is resolved against the workspace root and guarded against
     * traversal.
     * @param workspaceId - registered workspace owning the file.
     * @param path - workspace-relative path (POSIX spelling).
     * @returns the bounded file content.
     * @throws {@link WebWorkbenchError} for unknown workspaces, paths that
     * escape the workspace root, and read failures.
     */
    readFile(workspaceId: string, path: string): Promise<WorkspaceReadFile>;
    /**
     * List the changed files of one registered workspace, in git's own
     * porcelain order.
     * @param workspaceId - registered workspace to inspect.
     * @returns the current change list.
     * @throws {@link WebWorkbenchError} for unknown workspaces, non-repos,
     * and git failures.
     */
    listChanges(workspaceId: string): Promise<{
        items: ChangedFileView[];
    }>;
    /**
     * Read the bounded unified diff of one currently changed file. The path
     * must be a member of the workspace's current change list; anything else
     * fails with `file-not-changed`.
     * @param workspaceId - registered workspace owning the file.
     * @param path - repository-relative path of a changed file.
     * @returns the bounded diff.
     * @throws {@link WebWorkbenchError} for unknown workspaces, non-repos,
     * unlisted paths, and git failures.
     */
    readDiff(workspaceId: string, path: string): Promise<WorkspaceReviewDiff>;
    /**
     * Spawn one real PTY shell session under the given working directory.
     * @param cwd - working directory for the session (defaults to config cwd or host cwd).
     * @param cols - initial terminal columns.
     * @param rows - initial terminal rows.
     * @param cmd - optional program to launch instead of the shell (e.g. a TUI
     * file manager); the program runs in `cwd`.
     * @returns the new session id, the launched program, and the working directory.
     * @throws {@link WebWorkbenchError} when the session cap is reached or the
     * program cannot start.
     */
    terminalOpen(cwd?: string, cols?: number, rows?: number, cmd?: string): Promise<{
        sessionId: string;
        program: string;
        cwd: string;
    }>;
    /**
     * Write text to a session's PTY stdin.
     * @param sessionId - live session id.
     * @param data - text to deliver without implicit newline conversion.
     * @throws {@link WebWorkbenchError} for unknown sessions.
     */
    terminalWrite(sessionId: string, data: string): Promise<{
        accepted: true;
    }>;
    /**
     * Resize a session's PTY.
     * @param sessionId - live session id.
     * @param cols - new column count.
     * @param rows - new row count.
     * @throws {@link WebWorkbenchError} for unknown sessions.
     */
    terminalResize(sessionId: string, cols: number, rows: number): Promise<{
        resized: true;
    }>;
    /**
     * List live sessions (for the panel's connection status).
     * @returns one row per live session.
     */
    terminalList(): Promise<{
        sessions: TerminalSessionView[];
    }>;
    /**
     * Terminate a session's PTY and drop it.
     * @param sessionId - live session id.
     * @returns the close receipt.
     * @throws {@link WebWorkbenchError} for unknown sessions.
     */
    terminalClose(sessionId: string): Promise<{
        closed: true;
    }>;
    /**
     * Attach one upgraded WebSocket to a fresh PTY session. Query parameters:
     * `cwd` (working directory), `cols`/`rows` (initial size), `cmd` (optional
     * program, e.g. a TUI file manager). Client messages: `{type:'input',data}`,
     * `{type:'resize',cols,rows}`, `{type:'close'}`. Server messages:
     * `{type:'ready',sessionId,program}`, `{type:'output',data}`,
     * `{type:'exit',exitCode}`. The session is owned by the socket.
     * @param ws - the upgraded socket.
     * @param req - the upgrade request (URL carries the query parameters).
     */
    attachTerminalSocket(ws: WebSocket, req: IncomingMessage): void;
    /**
     * Open one workspace-relative path in the system file manager (e.g.
     * nautilus/dolphin via xdg-open). The path must resolve inside the
     * registered workspace root.
     * @param workspaceId - registered workspace owning the path.
     * @param path - workspace-relative path (POSIX spelling); defaults to the workspace root.
     * @returns the open receipt.
     * @throws {@link WebWorkbenchError} for unknown workspaces, escaping paths,
     * and spawn failures.
     */
    systemOpen(workspaceId: string, path?: string): Promise<{
        opened: true;
    }>;
    /**
     * Report the integration capabilities the browser UI can offer: whether a
     * TUI file manager is available and which system open command is used.
     * @returns the capability projection.
     */
    systemCapabilities(): Promise<{
        tuiFileManager: string | null;
        openCommand: string;
    }>;
    /**
     * Dispatch one /wb-api request: route by method + pathname, parse query or
     * JSON body, call the service method, and write a JSON response. Errors are
     * folded into the {@link WbApiErrorBody} envelope with a matching status.
     * @param req - node http request (full URL; the prefix is stripped here).
     * @param res - node http response.
     */
    handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void>;
    /** Route one (method, path) key to its service call. */
    private dispatch;
    private resolveWorkspace;
    private runStatus;
    private runGit;
    /**
     * Spawn one git invocation. Overridable so tests can substitute a
     * controllable child; production callers use the default `spawn`.
     * @param gitPath - git executable.
     * @param args - full argument array (root and fixed review arguments).
     * @param options - spawn options (pipes and pinned environment).
     * @returns the child process.
     */
    protected spawnChild(gitPath: string, args: readonly string[], options: SpawnOptions): ChildProcess;
    private gitFailure;
    private requireSession;
    private respondJson;
    private respondError;
}
export default WebWorkbenchService;
//# sourceMappingURL=index.d.ts.map