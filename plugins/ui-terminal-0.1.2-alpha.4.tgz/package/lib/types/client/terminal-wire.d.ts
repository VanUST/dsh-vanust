/**
 * Terminal wire protocol and cross-plugin open contract.
 * @module @deepseek-ai/dsh-client-ui-terminal/client/terminal-wire
 */
/**
 * Window CustomEvent contract for opening the terminal panel from another
 * plugin (e.g. the workbench Files tab). Payload: `{cwd, cmd?}` — cwd is the
 * absolute working directory, cmd optionally replaces the shell (e.g.
 * 'yazi'). The event name string is duplicated in the workbench package
 * (documented there); keep the two in sync.
 */
export declare const TERMINAL_OPEN_EVENT = "dsh:terminal.open";
/** Payload of the terminal-open event. */
export interface TerminalOpenDetail {
    /** Absolute working directory for the new session. */
    cwd: string;
    /** Optional program to launch instead of the shell (e.g. 'yazi'). */
    cmd?: string;
}
/** Dispatch a terminal-open request from any plugin. */
export declare function dispatchTerminalOpen(detail: TerminalOpenDetail): void;
/** Server message shapes over the terminal WebSocket. */
export type TerminalWsServerMessage = {
    type: 'ready';
    sessionId: string;
    program: string;
} | {
    type: 'output';
    data: string;
} | {
    type: 'exit';
    exitCode: number;
} | {
    type: 'error';
    code: string;
    message: string;
};
/** Client message shapes over the terminal WebSocket. */
export type TerminalWsClientMessage = {
    type: 'input';
    data: string;
} | {
    type: 'resize';
    cols: number;
    rows: number;
} | {
    type: 'close';
};
/**
 * Build the terminal WebSocket URL for the current origin.
 * @param opts - session parameters (cwd, optional program, initial size).
 * @returns the ws(s):// URL.
 */
export declare function terminalWsUrl(opts: {
    cwd?: string;
    cmd?: string;
    cols: number;
    rows: number;
}): string;
//# sourceMappingURL=terminal-wire.d.ts.map