/**
 * Runtime loader for the vendored xterm.js asset, served by the host bridge
 * at `/wb-api/static/xterm.js` (+ its stylesheet). The UMD bundle attaches
 * `Terminal` to the window global; the loader fetches it once and exposes a
 * typed facade over the surface this package uses.
 * @module @deepseek-ai/dsh-client-ui-terminal/client/xterm-loader
 */
/** Options accepted by the Terminal constructor. */
export interface XTerminalOptions {
    cols?: number;
    rows?: number;
    scrollback?: number;
    fontSize?: number;
    fontFamily?: string;
    theme?: Record<string, string>;
    cursorBlink?: boolean;
    convertEol?: boolean;
}
/** Disposer returned by event registrations. */
export interface XTerminalDisposable {
    dispose(): void;
}
/** Terminal resize event payload. */
export interface XTerminalResizeEvent {
    cols: number;
    rows: number;
}
/** Terminal exit event payload. */
export interface XTerminalExitEvent {
    exitCode: number;
}
/** The terminal emulator surface used by the panel. */
export interface XTerminal {
    readonly cols: number;
    readonly rows: number;
    open(parent: HTMLElement): void;
    write(data: string): void;
    resize(cols: number, rows: number): void;
    dispose(): void;
    focus(): void;
    onData(cb: (data: string) => void): XTerminalDisposable;
    onResize(cb: (event: XTerminalResizeEvent) => void): XTerminalDisposable;
    onExit(cb: (event: XTerminalExitEvent) => void): XTerminalDisposable;
}
/** Constructor face of the xterm Terminal class. */
export interface XTerminalConstructor {
    new (options?: XTerminalOptions): XTerminal;
}
/**
 * Load the xterm script (once) and return the Terminal constructor.
 * @returns the Terminal constructor.
 * @throws when the asset fails to load.
 */
export declare function loadXterm(): Promise<XTerminalConstructor>;
/** Inject the vendored xterm stylesheet link once. */
export declare function ensureXtermCss(): void;
//# sourceMappingURL=xterm-loader.d.ts.map