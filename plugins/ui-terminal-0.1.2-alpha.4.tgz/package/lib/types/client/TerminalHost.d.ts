/**
 * Terminal host: the header-utility toggle and the bottom shell strip for the
 * dsh web GUI. The strip is a live xterm.js terminal bridged to a real PTY on
 * the host over a per-session WebSocket: it opens a session when the strip
 * becomes visible, streams output, forwards input and resize, and closes the
 * session when the strip hides. Full-screen interactive programs work (the
 * PTY is a real kernel pty through node-pty).
 * @module @deepseek-ai/dsh-client-ui-terminal/client
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the terminal host occupant (session-scoped header utility). */
export type TerminalHostProps = PropsRuntime<'conversation.session.header.utilities'> & PropsLocale<typeof NS>;
/**
 * The terminal occupant: an in-flow header toggle plus, when open, a
 * bottom-anchored strip portal with the xterm surface. The shell opens in the
 * current session's registered workspace when one exists, else the host
 * default working directory. `cmd` (e.g. 'yazi') replaces the shell.
 */
export declare function TerminalHost({ sessionId, useWorkspaces, t }: TerminalHostProps): import("react").JSX.Element;
//# sourceMappingURL=TerminalHost.d.ts.map