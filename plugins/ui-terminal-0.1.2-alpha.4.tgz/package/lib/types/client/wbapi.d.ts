/**
 * Typed fetch client for the terminal wire (`/wb-api/terminal/*` and
 * `/wb-api/system/*`), served by `@deepseek-ai/dsh-host-web-workbench` on the
 * same origin as the SPA.
 * @module @deepseek-ai/dsh-client-ui-terminal/client/wbapi
 */
import type { TerminalApiErrorCode, TerminalSessionView } from './types.ts';
/** Typed rejection of a terminal wire call. */
export declare class TerminalApiError extends Error {
    /** Stable machine-readable failure category from the host envelope. */
    readonly code: TerminalApiErrorCode;
    /**
     * @param code - host envelope code.
     * @param message - host envelope message.
     */
    constructor(code: TerminalApiErrorCode, message: string);
}
/** The terminal wire face (session lifecycle; the interactive channel is the WebSocket). */
export declare const terminal: {
    /** List live sessions. */
    list(): Promise<{
        sessions: TerminalSessionView[];
    }>;
    /** Terminate a session. */
    close(sessionId: string): Promise<{
        closed: true;
    }>;
};
/** The system-integration wire face. */
export declare const system: {
    /** Open a workspace-relative path in the system file manager. */
    open(workspaceId: string, path?: string): Promise<{
        opened: true;
    }>;
    /** Report TUI file manager availability and the open command. */
    capabilities(): Promise<{
        tuiFileManager: string | null;
        openCommand: string;
    }>;
};
//# sourceMappingURL=wbapi.d.ts.map