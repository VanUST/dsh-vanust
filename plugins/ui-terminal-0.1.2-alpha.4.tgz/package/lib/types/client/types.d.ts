/**
 * Wire types of the terminal /wb-api client. Local mirror of the host
 * package's `types` module (`@deepseek-ai/dsh-host-web-workbench/types`) so
 * the client bundle stays free of host-package imports; keep the two in sync.
 * @module @deepseek-ai/dsh-client-ui-terminal/client/types
 */
/** One live terminal session row. */
export interface TerminalSessionView {
    /** Opaque session id (string form; minted by the host). */
    sessionId: string;
    /** Working directory the shell was spawned under. */
    cwd: string;
    /** Whether the shell process is still running. */
    running: boolean;
}
/** Stable machine-readable failure category of a /wb-api response. */
export type TerminalApiErrorCode = 'bad-request' | 'method-not-found' | 'session-not-found' | 'sessions-full' | 'shell-unavailable' | 'spawn-failed' | 'open-failed';
/** Error envelope of a failed /wb-api response. */
export interface TerminalApiErrorBody {
    error: {
        code: TerminalApiErrorCode;
        message: string;
    };
}
//# sourceMappingURL=types.d.ts.map