/**
 * Terminal plugin, browser half: one `conversation.session.header.utilities`
 * entry rendering the toggle and the bottom shell strip. The strip is a real
 * xterm.js terminal over a per-session WebSocket to the host's node-pty
 * bridge (`/wb-api/terminal/ws`) — full-screen interactive programs work.
 * The occupant reads the standard session/workspace kit to pick the shell
 * working directory; it owns no domain store.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type TerminalKey } from '../locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Terminal panel copy. */
        terminal: TerminalKey;
    }
}
export type { TerminalHostProps } from './TerminalHost.tsx';
export { TERMINAL_OPEN_EVENT, dispatchTerminalOpen, type TerminalOpenDetail } from './terminal-wire.ts';
/** Required services for locale registration and the header contribution. */
export declare const inject: string[];
/**
 * Client plugin body: register the dictionaries and the terminal header
 * toggle (which renders the bottom strip). Registration rides the slot
 * service's effect wrapper, so plugin unload removes every surface.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map