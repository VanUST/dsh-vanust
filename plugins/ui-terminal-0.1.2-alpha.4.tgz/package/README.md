---
description: "Bottom terminal panel for the dsh web GUI: a line-based shell over the /wb-api terminal wire with a frame-wide toggle."
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-terminal

## Summary

`dsh-client-ui-terminal` is the browser half of the web terminal pair (its
host half is `@deepseek-ai/dsh-host-web-workbench`, which serves the
`/wb-api/terminal/ws` WebSocket). One
`conversation.session.header.utilities` entry renders the in-flow header
toggle and, when open, a bottom-anchored strip portal. The strip is a real
xterm.js terminal (vendored, served by the host at `/wb-api/static/xterm.js`)
over a per-session WebSocket to a node-pty PTY — full-screen interactive
programs work.

The shell opens in the current session's registered workspace directory when
one exists, else the host-configured default. `cmd=yazi`-style launches (TUI
file managers) are offered through the strip header button and the
cross-plugin `dsh:terminal.open` window event (see `terminal-wire.ts`).

## Extension point

The toggle occupies `conversation.session.header.utilities` at order 100.
Unloading the plugin closes the shell and removes the toggle.

## Known limitations

- **xterm asset dependency** — the terminal needs the host's
  `/wb-api/static/xterm.js` asset; without the host plugin the panel shows a
  failure state.
- **Single session** — the strip owns one PTY session at a time; opening a
  new target (e.g. from Files) replaces the current session.

## Model Experience

None: the panel bridges a human terminal to a shell process; nothing here
reaches a model request.

#### KV Cache effect

None.
