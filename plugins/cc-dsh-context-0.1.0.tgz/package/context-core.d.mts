/**
 * Type surface for the harness plugin's pure core.
 *
 * The core is plain ESM because the harness loads `.mjs` directly, but this project is strictly
 * typed, so the shapes the tests rely on are declared here rather than reached through `any`.
 */

/** One inconsistency the core can decide about a specification set. */
export interface SpecProblem {
  readonly spec: string;
  readonly message: string;
}

/** A module's declared contract, read from its leading comments. */
export interface ModuleContract {
  readonly purpose: string | null;
  readonly links: readonly string[];
  readonly exports: readonly string[] | null;
}

/** Finds the project root by walking up from a directory, or `null` when none exists. */
export function findProjectRoot(start?: string): string | null;

/** Reports whether a path is the root or lies beneath it, comparing whole segments. */
export function withinRoot(path: string, root: string): boolean;

/** Reports whether two scope paths overlap. */
export function scopesOverlap(left: string, right: string): boolean;

/** Derives a stable module identifier from a repository-relative path. */
export function moduleIdFor(path: string): string;

/** Reads a module's declared contract from its leading comment run. */
export function readModuleContract(absolutePath: string): ModuleContract;

/** Lists source files a manifest's languages declare, sorted. */
export function listSources(root: string, manifest: unknown): readonly string[];

/** Reads and parses the project manifest. */
export function readManifest(root: string): { manifest?: unknown; error?: string };

/** Builds the actionable answer used when no manifest exists. */
export function noManifest(root: string | null): Record<string, unknown>;

/** Reads every specification file in a project. */
export function readSpecs(root: string): {
  readonly specs: readonly { id: string }[];
  readonly problems: readonly SpecProblem[];
};

/** Validates a specification set against a manifest. */
export function validateSpecs(
  specs: readonly unknown[],
  manifest: unknown,
): { readonly problems: readonly SpecProblem[]; readonly metrics: Record<string, number> };
