# @cc/dsh-taskboard

The task-centered dashboard that replaces the subagent catalog as the place work
is tracked.

## What it stores

One JSON ledger per session workspace, `.dsh/taskboard.json`:

- `id`, `revision`, `title`, `objective`, `chatId`
- `scope[]`, `nonScope[]`, `acceptance[{text,done}]`
- `status` — open, active, paused, review, done, blocked, cancelled
- `priority`, `owner`, `reason` (why a task is blocked), `parentId`, `parentSessionId`,
  `dependsOn[]`, `childSessionIds[]`,
  `children[{sessionId,label,role,status,startedAt,endedAt,stopReason}]`
- `role` + `preset` on a task, or `inline: true`; `agents[{role,label,sessionId,preset,status,taskCount,lastTaskId}]` for the persistent specialist roster
- `result { summary, evidence[], artifacts[], decisions[], risks[] }`
- `timeline[{at, kind, actor, text, sessionId?}]`

The `preset` on a roster row is the tool composition its child was started with, and the
pair `(role, preset)` is the row's identity. `registerAgent` refuses a second preset under a
name that already records one, with `preset_conflict` and the row left untouched; `force: true`
is the recorded exception and lands in the row's `history`. The delegator reuses a role's
session only when the requested preset matches it. A row with **no** preset predates the
roster and reads as `legacy`: its tasks stay on the board, it is never a reuse target, and an
explicit preset upgrades it once (history entry `{preset, adoptedAt, from: null}`).
`scripts/taskboard-migrate.mjs` repairs a board written before this contract (see
`rules/DEPLOYMENT.md` §1.0.0).

**A child that ends in error blocks its task.** `childEnded` moves a settled task to `review`
only when the child actually finished; a `stopReason` of `error`/`aborted`/`interrupted`/
`cancelled`/`timeout`/`failed` parks it in `blocked` with that reason and a `child_failed`
timeline entry. `reconcile(cwd)` (also `applyOp {op: "reconcile"}`) settles `active` rows the
ledger can prove have no running child: every linked child has a settled `children[]` entry; a
child with no entry, or one still `active`/`paused`, is left alone and counted.

## The project-state mirror

When `ccProjectState` is mounted, every created or updated task is also written as a TASK row
in `state/task/`, found again by `boardId`, so one board task stays one register row. The row
carries the concrete task — `scope`, `nonScope`, `acceptance[{text,done}]`, `role`/`preset` or
`inline`, `owner`, `steps`/`stepsDone`, the batch `reqIds` and the result — and the body is the
objective. `linkChild` mirrors as well, because the delegated child id is the fact the State
panel needs to open that session (`sessions` in the TASK); without that write the card would
know the task but not its executor. A field the panel clears (a removed scope line) is written
as an empty list, which the state core reads as a clear, not as "keep the old value". Without
the core the ledger behaves exactly as before; the requirement gate (`req_required`) exists
only when the core is mounted.

**Liveness is not the task status.** A task is `active` from the moment a child is linked until
it is accepted, so `status` cannot say whether anybody is working right now. `task_list` and
`task_get` therefore annotate every linked child with `running` from the runtime (`agents`
service): `true` running, `false` a known-idle session, the field absent when the runtime cannot
answer. The row also carries `runningChildSessionIds`. The panel reads the same truth from the
session snapshot; neither path infers activity from `active`.

## The lifecycle

Seven states, and no two of them mean the same thing:

| state | means | reached by |
| --- | --- | --- |
| `open` | created, nobody is working on it | `task_create` (it is the default) |
| `active` | a specialist child or the owner is working | `task_update`, `task_link`, `task_resume` |
| `paused` | held; linked children interrupted | `task_pause` |
| `review` | work claimed finished, waits for acceptance | `task_update` (with a result and evidence) or the child settling |
| `done` | accepted | `task_close`, only from `review` |
| `blocked` | cannot proceed, and says why | `task_update` with a `reason` |
| `cancelled` | terminal, not reachable from `done` | `task_cancel` (interrupts the children), or `task_update` for a childless task that is not paused |

`proposed` and `ready` were two names for "not started". They are not states any more: a row
that still says them is **display-mapped to `open` on read** and its bytes are left alone, so
the ledger format version stays 1 and no old row is rewritten by a read.

The transitions are enforced by the Host, in `transitionRefusal()`, because the model tools
and the human's panel reach the same service. Every refusal is a value with a named code:

| code | when |
| --- | --- |
| `needs_role_or_inline` | `open -> active` for a task with no role+owner and no `inline: true`; also `task_create` with neither |
| `needs_result` | `-> review` without a result summary |
| `needs_evidence` | `-> review` without one evidence item |
| `needs_reason` | `-> blocked` without a reason, and a BLANK reason on an already-blocked task |
| `use_pause` | `paused` set through an ordinary update |
| `use_close` | `done` set through an ordinary update, or a cancel of a task with linked children |
| `use_resume` | any move out of `paused` through an ordinary update |
| `needs_review` | `task_close` on a task that is not in review |
| `needs_result` | also `task_close` on a task whose result has no summary — the child settling is not an acceptance |
| `req_required` | `task_create` with the project-state core mounted and neither a `reqId` nor `chore: true` with a non-empty `choreReason`; the task is not written |
| `initial_status` | `task_create` with any status other than `open` (or `blocked` with its reason); a task is born open |
| `needs_revision` | a command-path write without the `expectedRevision` it read |
| `terminal` | any move out of `done` or `cancelled` |
| `other_chat` | a write from another chat's agent |

**A task is born open.** `task_create` refuses `done`, `cancelled`, `paused`, `active` and
`review` with `initial_status`, so `done` cannot be minted without an acceptance; `blocked` is
a real starting state and needs its reason.

**`task_cancel` is the door the transition table does not have.** An ordinary update refuses a
move out of `paused` (`use_resume`) and a cancel of a task that still has children (`use_close`),
which left a paused task and a delegated task impossible to abandon. `task_cancel` interrupts the
linked children (fail closed, like `task_pause`), writes `cancelled`, records the reason as a
decision on the result and as a timeline entry, and never rewrites a summary somebody wrote.
`done` is not cancellable: an accepted task stays accepted.

**`task_close` needs a result, and can take it in the same call.** A linked child settling still
moves its task to `review` — that is the runtime reporting that work finished — but closing
refuses until somebody wrote the summary and at least one evidence item (`needs_result` /
`needs_evidence`). "The child finished" is a signal; the acceptance is a judgement. The result
fields may ride the close itself (`resultSummary`, `resultEvidence`, ...), and they **fill only
what is missing**: an existing summary or evidence list is never rewritten. `task_close` and
`task_cancel` accept `ids` and perform a batch in one ledger write, returning a per-task result;
a batch is partial by design and is never reported as a whole-batch success when one row failed.

**The command registry is the human/client path; agents use the tools.** `delegate_task` and
the model tools carry `expectedRevision` in their schema. The `/taskboard` command has only what
the panel sends, so it checks it itself: every mutating op (`update`, `note`, `link`, `pause`,
`resume`, `close`, `cancel`, `remove`, `owner-status`) is refused with `needs_revision` when the
revision is missing and with `stale` when it moved. A create is the one exception — there is
nothing to compare yet.

**The owner can overrule the lifecycle, and only the owner.** The Project state panel's status
control sends `/taskboard {op: "owner-status", id, expectedRevision, status, reason?}`: any of the
seven statuses, with `transitionRefusal` skipped — `open -> done` and `open -> review` are allowed
here and refused to a tool call. No model tool exposes it, so an agent cannot mint an acceptance.
Every change leaves two trails: a `status` timeline entry with `actor: human` (`from`, `to`, the
reason) and a `waiver` event in the state journal with code `owner_status_override` (`from`, `to`,
reason, `by: human`, `boardId`, `taskId`). It is a compare-and-set like every other command op, a
terminal or held target (`done`, `cancelled`, `paused`) stops the linked children through the same
lease-aware interrupt as close/cancel (a child that will not stop fails the whole change), and the
mirror runs BEFORE the journal event so the event can name the TASK. Asking for the status a task
already has is a no-op (`unchanged: true`), not a new revision.

**The assignment is editable, and it is one field pair.** `task_update` accepts `role`,
`inline` and `owner` (the panel shows them beside the status), so a row written before the role
rule can be adopted instead of left unassigned: a role with an owner, or inline work. The
`open -> active` check reads the same patch, so both can arrive in one write; a task never
carries a role and `inline: true` at once, and `owner: null` clears the owner.

**No task is role-less.** A task either carries a `role` (and the `preset` its child runs
with) or it is `inline: true`: work the owner — the orchestrator or the human — does itself,
with no specialist child. `task_create` refuses the third case with
`needs_role_or_inline`; a delegated task's role is its owner until `task_link` replaces it
with the child session, which is what `open -> active` checks. A pre-rule row with neither is
labelled `unassigned` in the panel instead of being refused on read or rewritten.

**A chat has its own board.** `chatId` is the root session of the lineage that created
the task, so a delegated child's rows land on the parent chat's board instead of its own.
Reads default to the caller's chat; the whole workspace history is still one explicit
request away (`task_list` with scope `workspace`, or the panel's **All chats** toggle).
One file with a chat column, not one file per chat: the history cannot drift out of the
ledger it belongs to, and a new chat starts empty without deleting anything. Rows written
before `chatId` existed fall back to `parentSessionId`; rows with neither are workspace
history that only the human can edit.

The `agents[]` section is the persistent role registry: one child session per role, reused by every task that fits it. A role is not a task title. The file is the durable record. It survives a Host restart, lives in the
checkout's `.dsh/` directory (gitignored), and is the same document the browser
displays. Child→task links are persisted in `$DSH_HOME/taskboard-child-links.json`,
so a `subagent/end` after a Host or plugin reload still settles the task.

## Model surface

`task_create`, `task_get`, `task_list`, `task_update` (compare-and-set on
`expectedRevision`), `task_note`, `task_link`, and the lifecycle tools
`task_pause`, `task_resume`, `task_close` (one task or `ids`, with the result in the same call),
`task_cancel` (one task or `ids`), `task_stop` (force-stop a task's children or one session
without changing the status), `task_remove`. The orchestrator's
`delegate_task` requires a `role` (e.g. `UX/UI`, `BACKEND`, `BUSINESS`, `RESEARCH`) and reuses
that role's existing child session; it starts a child only when the role has none. The taskboard
stores the role registry in `agents[]`. Pause/cancel/close interrupt the children the task HOLDS through
`ctx.subagents` - a child whose lease belongs to another task is skipped and reported, never
stopped; a failed interrupt is reported per child and the task stays in its previous
state (fail closed). The hook passes the runtime's tagged authority — `{kind: 'ancestor',
agent}` for a live ancestor, `{kind: 'user', parentSessionId}` for the human/client path — so
both the orchestrator and the owner can stop a child. `task_stop` is the explicit forced-stop
primitive; it records the request on the timeline and leaves the status alone.

`task_list` takes `scope: chat` (default) or `scope: workspace`; `task_get` reads any task by
id, because knowing the id is the reason to look. A write from another chat is refused with
`other_chat` for an agent and allowed for the human, who owns the board, and a ROOT agent
may widen a note or an edit with `scope: 'workspace'` (the ledger is one per workspace; the
timeline records the originating chat) while a child session cannot widen at all. The refusal exists
so an id guessed or carried over from an earlier chat cannot silently rewrite work this chat
cannot see.

## Browser surface

- **Tasks** in the session header replaces the `subagent-catalog` cell. It is a
  ghost header action: the label is followed by a separate bordered count pill,
  so it reads `Tasks 4`, never a run-together `Tasks4`.
- **Tasks** icon in the sidebar panel list opens the full page. The icon inherits
  the row label color and draws no fill or border of its own; the sidebar row owns
  the selected background.
- **Board + detail**: five workflow columns — Open, Active, Review, Blocked, Done. The
  two states that are not stages share the column they belong to: a `paused` card sits
  under Active and a `cancelled` card under Done, and the card chip still says paused or
  cancelled. A detail panel edits title, status, objective, scope, non-scope, acceptance,
  result summary, evidence and the blocked reason, and states the one assignment rule
  above the status row. The detail stacks under the board when the panel is narrower than
  920px, and each list field shows four lines before scrolling (96px/84px textareas).
- **Back** is the leftmost top-bar action. It returns to the conversation from which the panel was opened: the header trigger captures its exact session, and the sidebar entry captures the retained main-view conversation. It is hidden when there is no originating chat.
- **Hide** lives in the task-detail header, beside the task id and title; it
  collapses the right pane and gives the board the full width. The selection is
  kept, and clicking or keyboard-selecting any card reopens the detail. There is
  no show/hide control in the top bar.
- **Scaling**: a **Board / List** switch sits in the top bar. List is the dense scan view — one row per task with **Status, Role, Task, Owner, Updated** — and becomes the default when a board has more than 8 tasks. The Role cell is the role chip plus its preset id and the child count, so the old Subagents column has no column of its own; Owner shows the child's label, `inline`, or `unowned`. A filter row adds title/scope/owner search and a status filter over all seven states; both views use the same filtered set and keep the detail pane. The kanban stays available for workflow shaped work.
- **Scope**: the filter row starts with **This chat / All chats**. This chat is the default
  and is the chat's board; All chats reads the whole workspace history in place, with
  foreign rows marked `other chat` (card chip and list column), and **Back** to This chat
  when the conversation changes. The header count, the top-bar count and the filter count
  all follow the active scope, and a chat with no tasks says how many exist elsewhere
  instead of looking broken. Switching scope drops a selection that is not in the new
  working set, so the detail pane never shows a task the visible board says is not there.
- **Wheel scrolling**: wheel input over the board is captured as one horizontal
  axis. A vertical mouse wheel, a horizontal trackpad gesture, and a diagonal
  gesture all move the board sideways; the page does not scroll vertically at
  the same time. The listener is native and non-passive. At a horizontal edge
  the board stops rather than chaining the page. Move the pointer off the board
  to scroll the page. The list view keeps normal vertical page scrolling.
- **Subagents**: a task's `children[]` entries render as role-first rows with the
  label/id, an `active`/`sleeping`/`paused` badge and an **Open** action. A
  one-line summary above the rows reads e.g.
  `2 subagents · 1 active · 1 sleeping`. The board top carries a compact roster
  with total, active, sleeping (paused/linked when present) and every role name
  with its count. **The roster describes the board in view**: in *This chat* it
  counts only the roles linked to this chat's tasks (rows opened for them, or
  rows recording this chat), and *All chats* switches the label to **Workspace
  roles** and counts the whole `agents[]` registry. Reading it off the whole
  registry reported specialists from earlier chats that nobody here could reach.
  Card chips show the role (or `inline`), the child count and its
  active/sleeping split. Tasks without `children[]` fall back to
  `childSessionIds[]` with role `child` and neutral state `linked`.
- **Lifecycle**: **Pause** moves the task to `paused` and interrupts its linked
  child sessions; **Resume** moves it back to `active` (it does not auto-prompt a
  child; open the child to continue). **Cancel** abandons the task, interrupts its
  children and keeps the row as `cancelled` with the reason on its decisions — the
  only door for a paused task or one that still has children. **Close** accepts a task as done and
  interrupts children; it is enabled only for a task in review, because acceptance
  is the one door to `done`, and it refuses to mark done if the subagent service
  cannot be reached. **Remove** deletes the task and its timeline after a
  confirmation, and deliberately leaves child sessions running. `paused` and
  `done` are lifecycle states, not ordinary edit values: the status select
  disables those options and Save never submits them; `blocked` needs the reason
  in the field beside it. Host refusals such as `needs_role_or_inline`,
  `needs_result`, `needs_evidence`, `needs_reason`, `use_pause`, `use_close`,
  `needs_review`, `terminal`, `empty_title` or `interrupt_failed` are shown as
  errors in the detail pane. The header badge counts the same chat the pane shows:
  it resolves the session to the root of its lineage (`chatIdOf`) instead of comparing a
  task's `chatId` with the raw session id, which showed 0 on a child conversation.
- **Timeline**: created, edited, delegated, child started/finished, paused,
  resumed, closed, notes.
- **Child sessions**: each linked child opens its existing conversation.
- **Artifacts**: paths from the result, ready for `present` or the preview.

The browser reads the ledger through the existing `workspaceFiles.read` Remote
and writes through the existing `/taskboard` command Remote. There is no custom
Typert namespace and no second RPC layer.

## Save model

Save is kept on purpose. It is an explicit commit of one batch of fields, not a
keystroke autosave. The Host's compare-and-set (`expectedRevision`) has one
well-defined moment to succeed or return a stale conflict, so two editors cannot
interleave silently; a debounce would move that moment around without removing
the conflict. The client therefore:

- keeps the dirty hint and the disabled **Saved** state;
- disables Save for an empty title and says why;
- preserves acceptance `{text,done}` flags when the text is unchanged, and keeps
  `result.artifacts`, `result.decisions` and `result.risks` when saving
  summary/evidence;
- merges the returned task immediately, so Save visibly advances `rev`;
- treats a write without a recognizable command result as an error;
- keeps the board, selection and draft on a failed write. A background poll may
  not clear a write error; only a successful write does;
- when a poll sees a new revision while the draft is dirty, keeps the draft and
  shows a conflict banner with **Refresh** instead of discarding the edit.

The page picks a live/retained session for the selected workspace
(`retainedBy.mainView > 0` from the `useSessions` standard prop) rather than
`sessionIds[0]`. When no live session exists, the board is read-only and says
**Open a live conversation to edit this board**; Save and lifecycle actions are
disabled instead of failing silently. The header trigger still passes its exact
live session and is left alone.

## Failure behavior

- A stale save is rejected with the current revision; the client keeps the dirty
  draft and offers Refresh. A malformed ledger fails the read loudly rather than
  replacing the human's work. The Host writes temp-file + rename, so a crash
  cannot leave half a JSON document.
- **One writer at a time, across processes.** The read-modify-write holds a directory
  lock next to the file (`<ledger>.lock`, created with `mkdir`, which is `O_EXCL` on the
  filesystem). A second process WAITS for the lock (`lockWaitMs`, default 10 s) and then
  writes, so it cannot replace a board it read before the first process wrote its rows; a
  lock older than `lockStaleMs` (default 30 s) belongs to a process that died holding it
  and is taken over. A wait that runs out is refused by name, never silently overwritten.
- **A child that disappeared no longer blocks acceptance.** Whether a linked child is alive
  is asked of the RUNTIME (`agents.get`/`agents.list`), not inferred from `subagent/end`:
  that event only exists in the process that saw the child settle, so after a restart the
  row says `active` forever. A child the runtime no longer holds is settled like a finished
  one - the task closes as usual, the child row is marked settled, the role is freed, and the
  tool result names it in `gone`. A child the runtime still runs is interrupted as before,
  and a refused interrupt still fails closed. The first read of a board in a process settles
  `active` rows whose linked children have finished or disappeared.
- A write from another chat is refused with `other_chat` for an agent; the panel
  (the human) may still fix an old row it is reading, which is why Remove on an
  earlier chat's task works from the All-chats view.
- A read stops on `eof`. If the ledger does not reach `eof` within 200 pages of
  2,000 lines, the read returns `ledger is too large to read` instead of parsing
  truncated JSON (a maximal board is about 75 pages).
- **The cap counts work in flight, not history.** `maxTasks` (default 200) limits the
  tasks that can still be acted on — open, active, paused, review, blocked — and a create
  past it is refused with `board_full` plus the counts (`active`, `cap`). Finished and
  cancelled rows are the record of what the board did; they do not occupy a slot, so a
  workspace with 190 done rows and 5 open ones can still add work.
  **`maxTasks: 0` means UNLIMITED** and skips the work-in-flight check entirely: a ledger
  with 400 actionable rows still accepts a new task. It has to be spelled `0`; a negative, a
  string or a missing key keeps the 200 default, because a typo must not silently remove a
  cap. The kit's own profile mounts `maxTasks: 0` for this workspace.
- **There is no row limit unless the workspace asks for one.** `maxRows` has no default: the
  shipped 1000-row guard refused new work on a real board with 1000 rows of history, so a
  missing key now means unlimited. A positive integer sets the limit (a create past it is
  refused with `board_rows_full`, carrying `rows` and `cap`), and `0` is the explicit spelling
  of no limit. Nothing is ever evicted, deleted or rewritten to make space — the row limit is
  a decision the owner makes, never a default the plugin imposes.
- The ledger has no cross-process file lock. Run one DSH host per workspace;
  a second host writing the same checkout can lose an update (the UI shows the
  `session/writer-held` failure instead of pretending it saved).
