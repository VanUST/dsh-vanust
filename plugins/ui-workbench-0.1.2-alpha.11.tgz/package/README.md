---
description: "Floating workbench for the dsh web GUI: Files (workspace tree + preview), Review (git changes/diff) and Browser (iframe) tabs over the /wb-api host wire."
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-workbench

## Summary

`dsh-client-ui-workbench` is the browser half of the web workbench plugin pair
(its host half is `@deepseek-ai/dsh-host-web-workbench`). One
`conversation.session.header.utilities` entry renders the in-flow header
toggle and, when open, a right-anchored panel portal with three internal
tabs:

| Tab | Data source | Behavior |
|---|---|---|
| Files | `GET /wb-api/workspace/list` + `read` + `media` | collapsible workspace file tree with sizes, per-file preview (text, images, and video playback with seeking), tree↕preview splitter, refresh |
| Review | `GET /wb-api/workspace/changes` + `diff` | sorted git change list with status badges, per-file bounded unified diff, refresh |
| Browser | client-side iframe | address bar with back/forward/reload, URL normalization to http(s), embedded sandboxed viewer |

The Files toolbar also integrates existing file managers: **Open in terminal**
and the detected TUI file manager (yazi/ranger/mc via
`/wb-api/system/capabilities`) dispatch the cross-plugin `dsh:terminal.open`
event with the selected directory, and **System file manager** launches the
desktop file manager (nautilus/dolphin via xdg-open) on the directory through
`/wb-api/system/open`.

The panel is a projection of the standard session/workspace kit (the
`useSessions`/`useWorkspaces` hooks every slot occupant receives) plus the
`/wb-api` wire: the current session's registered workspace selects the file
surface, and without one every tab shows its no-workspace state. The plugin
owns no domain store and issues no RPC outside the wire.

The panel **composes** with the layout (i3-style): while open, the layout frame
reserves the panel's width at its right (`data-dsh-workbench-open` +
`--dsh-workbench-width`), so the chat column narrows instead of being covered; when
the terminal strip is also open, the panel floats above its band. The panel's
left edge is a drag handle: dragging rewrites `--dsh-workbench-width` live
and the last width is persisted in localStorage (`dsh.workbenchWidth`) and
restored on boot. The Files preview is a vertical tile of its own: a splitter
between the file tree and the preview (rewrites `--dsh-files-preview-height`,
persisted as `dsh.filesPreviewHeight`) sizes the media area, and images/videos
fit the tile (shrink to fit, never upscaled beyond native resolution).

## Extension point

The toggle occupies `conversation.session.header.utilities` at order 110
(after the terminal toggle), in-flow with the session header's other
utilities — nothing is overlaid on existing controls. The panel is rendered
via a body portal from the same occupant; unloading the plugin removes both.

## Wire types

The browser bundle must stay free of host-package imports, so the wire types
(`src/client/types.ts`) are a deliberate local mirror of
`@deepseek-ai/dsh-host-web-workbench/types` — keep the two in sync when the
wire changes.

## Model Experience

None: every tab renders browser-side workspace/git state for a human; nothing
here reaches a model request.

#### KV Cache effect

None.
