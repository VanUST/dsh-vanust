/**
 * Typed fetch client for the system wire (`/wb-api/system/*`), served by
 * `@deepseek-ai/dsh-host-web-workbench` on the same origin as the SPA.
 * @module @deepseek-ai/dsh-client-ui-editor/client/wbapi
 */
/** Typed rejection of a system wire call. */
export declare class SystemApiError extends Error {
    /** Stable machine-readable failure category from the host envelope. */
    readonly code: string;
    /**
     * @param code - host envelope code.
     * @param message - host envelope message.
     */
    constructor(code: string, message: string);
}
/** The system-integration wire face. */
export declare const system: {
    /** Report TUI file manager / editor availability and the open command. */
    capabilities(): Promise<{
        tuiFileManager: string | null;
        editor: string | null;
        openCommand: string;
    }>;
};
//# sourceMappingURL=wbapi.d.ts.map