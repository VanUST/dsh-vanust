/**
 * Editor wire contract and cross-plugin open event.
 * @module @deepseek-ai/dsh-client-ui-editor/client/editor-wire
 */
/**
 * Window CustomEvent contract for opening the editor panel from another
 * plugin (e.g. the workbench Files tab). Payload: `{path?}` — a
 * workspace-relative file path; without one micro opens the workspace
 * directory browser. The event name string is mirrored in the workbench
 * package (documented there); keep the two in sync.
 */
export declare const EDITOR_OPEN_EVENT = "dsh:editor.open";
/** Payload of the editor-open event. */
export interface EditorOpenDetail {
    /** Workspace-relative file path to open, when a file was chosen. */
    path?: string;
}
/** Dispatch an editor-open request from any plugin. */
export declare function dispatchEditorOpen(detail: EditorOpenDetail): void;
/** Server message shapes over the editor's terminal WebSocket. */
export type EditorWsServerMessage = {
    type: 'ready';
    sessionId: string;
    program: string;
} | {
    type: 'output';
    data: string;
} | {
    type: 'exit';
    exitCode: number;
} | {
    type: 'error';
    code: string;
    message: string;
};
/** Client message shapes over the editor's terminal WebSocket. */
export type EditorWsClientMessage = {
    type: 'input';
    data: string;
} | {
    type: 'resize';
    cols: number;
    rows: number;
} | {
    type: 'close';
};
/**
 * Build the editor's terminal WebSocket URL for the current origin. The
 * editor reuses the terminal wire: `cmd` names the editor program and `argv`
 * carries its arguments (e.g. the file path), both as query parameters.
 * @param opts - session parameters (cwd, program, arguments, initial size).
 * @returns the ws(s):// URL.
 */
export declare function editorWsUrl(opts: {
    cwd?: string;
    cmd: string;
    argv?: readonly string[];
    cols: number;
    rows: number;
}): string;
//# sourceMappingURL=editor-wire.d.ts.map