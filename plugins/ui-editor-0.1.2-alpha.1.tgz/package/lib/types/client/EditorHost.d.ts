/**
 * Editor host: the header-utility toggle and the right-anchored micro panel
 * for the dsh web GUI. One `conversation.session.header.utilities` entry
 * renders the in-flow toggle and, when open, a portal panel running micro in
 * a real PTY over the terminal WebSocket (`/wb-api/terminal/ws` with
 * `cmd=micro&argv=[path]`). The panel tiles the layout (i3-style) beside the
 * workbench panel: while open, the frame reserves `--dsh-editor-width` at
 * its right, and the editor sits left of the workbench when both are open.
 * @module @deepseek-ai/dsh-client-ui-editor/client
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the editor host occupant (session-scoped header utility). */
export type EditorHostProps = PropsRuntime<'conversation.session.header.utilities'> & PropsLocale<typeof NS>;
/**
 * The editor occupant: an in-flow header toggle plus, when open, a
 * right-anchored panel portal with the micro xterm surface. The session's
 * workspace is derived from the standard kit; the editor opens the file
 * requested through the `dsh:editor.open` event, else the workspace root.
 */
export declare function EditorHost({ sessionId, useWorkspaces, t }: EditorHostProps): import("react").JSX.Element;
//# sourceMappingURL=EditorHost.d.ts.map