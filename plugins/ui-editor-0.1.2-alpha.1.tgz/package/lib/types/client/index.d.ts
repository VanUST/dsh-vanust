/**
 * Editor plugin, browser half: one `conversation.session.header.utilities`
 * entry rendering the in-flow toggle and the right-anchored micro panel over
 * the /wb-api terminal wire (cmd=micro). The occupant reads the standard
 * session/workspace kit only to pick the working directory; it owns no
 * domain store.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type EditorKey } from '../locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Editor panel copy. */
        editor: EditorKey;
    }
}
export type { EditorHostProps } from './EditorHost.tsx';
export { EDITOR_OPEN_EVENT, dispatchEditorOpen, type EditorOpenDetail } from './editor-wire.ts';
/** Required services for locale registration and the header contribution. */
export declare const inject: string[];
/**
 * Client plugin body: register the dictionaries and the editor header toggle
 * (which renders the right panel). Registration rides the slot service's
 * effect wrapper, so plugin unload removes every surface.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map