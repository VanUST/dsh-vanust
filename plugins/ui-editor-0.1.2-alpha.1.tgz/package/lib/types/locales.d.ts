/**
 * Editor dictionary. The key union is derived from the Chinese dictionary
 * (`keyof typeof zh`), matching the stock client locale pattern.
 * @module @deepseek-ai/dsh-client-ui-editor/src/locales
 */
/** Chinese dictionary — the key source. */
export declare const zh: {
    readonly 'editor.toggle': "编辑器";
    readonly 'editor.close': "关闭编辑器";
    readonly 'editor.opening': "正在打开 micro…";
    readonly 'editor.ready': "micro";
    readonly 'editor.failed': "编辑器启动失败";
    readonly 'editor.noWorkspace': "该会话没有注册的工作区";
    readonly 'editor.missing': "未找到 micro — 请先安装 (apt install micro / winget install micro)";
};
/** Message keys of the editor plugin. */
export type EditorKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<EditorKey, string>;
/** Namespace id of the editor dictionaries. */
export declare const NS = "editor";
//# sourceMappingURL=locales.d.ts.map