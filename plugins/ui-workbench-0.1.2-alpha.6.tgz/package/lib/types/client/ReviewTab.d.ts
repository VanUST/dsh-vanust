import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the review tab. */
export interface ReviewTabProps {
    /** Registered workspace id for the current session, when one exists. */
    workspaceId: string | undefined;
    /** Bound locale translate function. */
    t: TranslateNS<typeof NS>;
}
export declare function ReviewTab({ workspaceId, t }: ReviewTabProps): import("react").JSX.Element;
//# sourceMappingURL=ReviewTab.d.ts.map