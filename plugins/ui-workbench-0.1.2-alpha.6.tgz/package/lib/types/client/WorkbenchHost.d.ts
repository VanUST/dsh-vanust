/**
 * Workbench host: the header-utility toggle and the floating panel for the
 * dsh web GUI. One `conversation.session.header.utilities` entry renders the
 * in-flow toggle and, when open, a right-anchored workbench portal with
 * internal Files/Review/Browser tabs. The workbench is a projection of the
 * standard session/workspace kit plus the /wb-api wire; it owns no domain
 * store.
 * @module @deepseek-ai/dsh-client-ui-workbench/client
 */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the workbench host occupant (session-scoped header utility). */
export type WorkbenchHostProps = PropsRuntime<'conversation.session.header.utilities'> & PropsLocale<typeof NS>;
/** One workbench tab id. */
export type WorkbenchTab = 'files' | 'review' | 'browser';
/**
 * The workbench occupant: an in-flow header toggle plus, when open, a
 * right-anchored panel portal with the three tabs. The current session's
 * registered workspace is derived from the standard kit; without one, the
 * tabs show their no-workspace state.
 */
export declare function WorkbenchHost({ sessionId, useWorkspaces, t }: WorkbenchHostProps): import("react").JSX.Element;
//# sourceMappingURL=WorkbenchHost.d.ts.map