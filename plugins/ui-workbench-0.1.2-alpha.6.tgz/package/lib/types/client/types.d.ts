/**
 * Wire types of the workbench /wb-api client. Deliberate local mirror of the
 * host package's `types` module (`@deepseek-ai/dsh-host-web-workbench/types`):
 * the client bundle must stay free of host-package imports, and the host
 * package's browser-safe types module documents the source of truth. Keep the
 * two in sync when the wire changes.
 * @module @deepseek-ai/dsh-client-ui-workbench/client/types
 */
/** One entry of a workspace file listing. */
export interface WorkspaceFileEntry {
    /** Workspace-relative POSIX path; a directory path has no trailing slash. */
    path: string;
    /** Base name shown in a browser row. */
    name: string;
    /** Whether the entry is a directory rather than a regular file. */
    kind: 'file' | 'directory';
    /** File size in bytes; absent for directories. */
    size?: number;
}
/** Bounded recursive listing of one workspace. */
export interface WorkspaceFileListing {
    /** Entries in walk order (directories before files, each level sorted). */
    items: WorkspaceFileEntry[];
    /** Whether the host's configured entry cap cut the walk. */
    truncated: boolean;
}
/** Bounded readable content of one workspace file. */
export interface WorkspaceReadFile {
    /** UTF-8 file content, cut at the host's configured byte cap when large. */
    content: string;
    /** Whether the host's configured byte cap cut the file mid-stream. */
    truncated: boolean;
    /** Resolved workspace-relative path (POSIX spelling). */
    path: string;
}
/** Closed review status vocabulary (folded from git porcelain letters). */
export type WorkspaceReviewStatus = 'added' | 'modified' | 'deleted' | 'renamed' | 'copied' | 'untracked' | 'unmerged' | 'type-changed';
/** One changed file as the Review surface sees it. */
export interface ChangedFileView {
    /** Repository-relative path in POSIX spelling (git's own output form). */
    path: string;
    /** Folded porcelain status. */
    status: WorkspaceReviewStatus;
    /** Whether the change is staged in the index. */
    staged: boolean;
    /** Source path of a rename or copy, when git reported one. */
    oldPath?: string;
}
/** Bounded unified diff of one changed file. */
export interface WorkspaceReviewDiff {
    /** Unified diff text; an untracked file is presented as an all-additions diff. */
    diff: string;
    /** Whether the host's configured byte cap cut the diff mid-output. */
    truncated: boolean;
}
/** Stable machine-readable failure category of a /wb-api response. */
export type WbApiErrorCode = 'bad-request' | 'method-not-found' | 'workspace-not-found' | 'path-escapes-root' | 'list-failed' | 'read-failed' | 'not-a-git-repo' | 'git-unavailable' | 'git-failed' | 'file-not-changed' | 'session-not-found' | 'sessions-full' | 'shell-unavailable' | 'spawn-failed';
/** Error envelope of a failed /wb-api response. */
export interface WbApiErrorBody {
    error: {
        code: WbApiErrorCode;
        message: string;
    };
}
//# sourceMappingURL=types.d.ts.map