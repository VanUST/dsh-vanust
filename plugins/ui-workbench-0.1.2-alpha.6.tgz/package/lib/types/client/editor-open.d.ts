/**
 * Cross-plugin editor-open contract (mirrored from
 * `@deepseek-ai/dsh-client-ui-editor/client`). The event name string must
 * stay in sync with the editor package; see its README for the wire
 * contract.
 * @module @deepseek-ai/dsh-client-ui-workbench/client/editor-open
 */
/** Window CustomEvent name the editor panel listens for. */
export declare const EDITOR_OPEN_EVENT = "dsh:editor.open";
/** Payload of the editor-open event. */
export interface EditorOpenDetail {
    /** Workspace-relative file path to open, when a file was chosen. */
    path?: string;
}
/** Dispatch an editor-open request (opens the editor panel on the file). */
export declare function dispatchEditorOpen(detail: EditorOpenDetail): void;
//# sourceMappingURL=editor-open.d.ts.map