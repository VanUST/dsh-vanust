import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the browser tab. */
export interface BrowserTabProps {
    /** Bound locale translate function. */
    t: TranslateNS<typeof NS>;
}
/**
 * Normalize a typed address into an absolute http(s) URL. Bare hosts gain
 * `https://`; other schemes and unparseable text are rejected.
 * @param raw - the address bar value.
 * @returns the normalized URL, or null when invalid.
 */
export declare function normalizeUrl(raw: string): string | null;
export declare function BrowserTab({ t }: BrowserTabProps): import("react").JSX.Element;
//# sourceMappingURL=BrowserTab.d.ts.map