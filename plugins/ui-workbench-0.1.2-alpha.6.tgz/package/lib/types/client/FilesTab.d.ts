import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { WorkspaceFileEntry } from './types.ts';
import { NS } from '../locales.ts';
/** One node of the client-side tree assembled from the flat wire listing. */
interface TreeNode {
    path: string;
    name: string;
    kind: 'file' | 'directory';
    size?: number;
    children: TreeNode[];
}
/**
 * Assemble the flat wire listing into a tree. The host emits parents before
 * descendants, so this only needs one pass; missing parents are created
 * defensively so a truncated walk still renders what it has.
 * @param items - flat listing in walk order.
 * @returns root-level nodes.
 */
export declare function buildTree(items: readonly WorkspaceFileEntry[]): TreeNode[];
/** Full props of the files tab. */
export interface FilesTabProps {
    /** Registered workspace id for the current session, when one exists. */
    workspaceId: string | undefined;
    /** Absolute path of the current session's workspace, when one exists. */
    workspacePath: string | undefined;
    /** Bound locale translate function. */
    t: TranslateNS<typeof NS>;
}
export declare function FilesTab({ workspaceId, workspacePath, t }: FilesTabProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=FilesTab.d.ts.map