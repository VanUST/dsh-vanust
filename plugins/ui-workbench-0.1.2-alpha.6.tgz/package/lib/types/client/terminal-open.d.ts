/**
 * Cross-plugin terminal-open contract (mirrored from
 * `@deepseek-ai/dsh-client-ui-terminal/client`). The event name string must
 * stay in sync with the terminal package; see its README for the wire
 * contract.
 * @module @deepseek-ai/dsh-client-ui-workbench/client/terminal-open
 */
/** Window CustomEvent name the terminal panel listens for. */
export declare const TERMINAL_OPEN_EVENT = "dsh:terminal.open";
/** Payload of the terminal-open event. */
export interface TerminalOpenDetail {
    /** Absolute working directory for the new session. */
    cwd: string;
    /** Optional program to launch instead of the shell (e.g. 'yazi'). */
    cmd?: string;
}
/** Dispatch a terminal-open request (opens the terminal panel with these params). */
export declare function dispatchTerminalOpen(detail: TerminalOpenDetail): void;
//# sourceMappingURL=terminal-open.d.ts.map