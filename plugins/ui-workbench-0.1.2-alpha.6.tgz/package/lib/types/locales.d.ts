/**
 * Workbench dictionary. The key union is derived from the Chinese dictionary
 * (`keyof typeof zh`), matching the stock client locale pattern; every
 * consumer types its `t` against it.
 * @module @deepseek-ai/dsh-client-ui-workbench/src/locales
 */
/** Chinese dictionary — the key source. */
export declare const zh: {
    readonly 'workbench.toggle': "工作台";
    readonly 'workbench.close': "关闭工作台";
    readonly 'files.title': "文件";
    readonly 'files.refresh': "刷新";
    readonly 'files.listFailed': "无法列出工作区文件";
    readonly 'files.readFailed': "无法读取文件";
    readonly 'files.noWorkspace': "该会话没有注册的工作区";
    readonly 'files.size.bytes': "{bytes} B";
    readonly 'files.size.kb': "{kb} KB";
    readonly 'files.size.mb': "{mb} MB";
    readonly 'files.truncated': "列表已超出主机上限被截断";
    readonly 'files.action.terminal': "在终端中打开";
    readonly 'files.action.system': "系统文件管理器";
    readonly 'review.title': "审查";
    readonly 'review.refresh': "刷新";
    readonly 'review.failed': "无法读取 git 变更";
    readonly 'review.notGit': "工作区不是 git 仓库";
    readonly 'review.gitUnavailable': "git 可执行文件不可用";
    readonly 'review.diffFailed': "无法读取 diff";
    readonly 'review.noWorkspace': "该会话没有注册的工作区";
    readonly 'review.empty': "没有变更";
    readonly 'review.staged': "已暂存";
    readonly 'review.diff.truncated': "diff 已超出主机上限被截断";
    readonly 'review.status.added': "新增";
    readonly 'review.status.modified': "修改";
    readonly 'review.status.deleted': "删除";
    readonly 'review.status.renamed': "重命名";
    readonly 'review.status.copied': "复制";
    readonly 'review.status.untracked': "未跟踪";
    readonly 'review.status.unmerged': "未合并";
    readonly 'review.status.type-changed': "类型变更";
    readonly 'browser.title': "浏览器";
    readonly 'browser.url': "输入网址";
    readonly 'browser.go': "前往";
    readonly 'browser.back': "后退";
    readonly 'browser.forward': "前进";
    readonly 'browser.reload': "刷新";
    readonly 'browser.empty': "输入网址以预览页面";
    readonly 'browser.invalid': "仅支持 http(s) 网址";
    readonly 'status.loading': "加载中…";
};
/** Message keys of the workbench plugin. */
export type WorkbenchKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<WorkbenchKey, string>;
/** Namespace id of the workbench dictionaries. */
export declare const NS = "workbench";
//# sourceMappingURL=locales.d.ts.map