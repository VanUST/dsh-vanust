/**
 * Ratchet tool surface: the ratchet's operations, declared as harness tools.
 *
 * This file is an adapter and nothing else. It resolves the project root from the
 * session workspace, declares the model-facing schemas, shapes responses, and owns
 * the two harness connections — the subagent runtime a judge is spawned on, and the
 * user-questions channel a ratification is put to a human through. Every decision
 * about what a project's laws are, whether the code obeys them, whether a human
 * consented, and what a report says lives in `ratchet-schema.mjs`,
 * `ratchet-compiler.mjs`, `ratchet-verifier.mjs`, `ratchet-state.mjs`,
 * `ratchet-ratify.mjs` and `ratchet-ops.mjs`, none of which import the harness.
 *
 * It also PROVIDES two services for the one caller that is not an agent: the ADR panel's
 * host half, which reaches them from HTTP routes behind the browser trust fence.
 * `ratchetConsent` (`ratchet-consent.mjs`) builds the ratchet's own ratification question
 * and records a human's answer; `ratchetDecisions` (`ratchet-decisions.mjs`) derives the
 * complete view model a window renders — every record's force, consent match and queue
 * membership, plus the compiled spec documents — from the ratchet's own functions, so no
 * non-agent surface re-implements a rule. Both are values, not tools, and neither exposes
 * an operation a tool or a command argument could reach — a surface that could accept a
 * composed answer would be the second consent path this whole design refuses, and a
 * surface that re-derived force would be the second truth this design removes.
 *
 * That split is not tidiness. It is what lets the gate be run by a shell and by a
 * test through the SAME code path the model calls, so "the gate fails when it
 * should" is a fact about the gate rather than a claim about a tool declaration.
 * The test suite exercises the operations directly and needs no harness, no
 * credentials and no model.
 *
 * Two harness facts constrain the declarations, both measured rather than assumed
 * (see `docs/RATCHET-API-FACTS.md`):
 *
 *   - Every tool is declared with `defineTool`. A definition registered directly
 *     against `ctx.tools.register()` is validated as RAW JSON Schema, so a
 *     zero-argument tool whose parameter root lacks a `type` makes the provider
 *     reject the entire request with `Invalid schema for function …`.
 *   - `inject: ['tools']` is the whole dependency. Nothing here reaches the
 *     subagent runtime, the user-questions channel or any optional service through
 *     injection, so a deployment that mounts only the base bundle can still compile
 *     and verify.
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { resolve } from 'node:path'
import { MANIFEST_PATH, PROBLEM_CODES, createWorkBudget } from './ratchet-schema.mjs'
import { CONSENT_SERVICE, createConsentService } from './ratchet-consent.mjs'
import { DECISIONS_SERVICE, createDecisionsService } from './ratchet-decisions.mjs'
import { RESOLVE_SERVICE, createResolveService } from './ratchet-resolve.mjs'
import { REVIEW_JOBS } from './ratchet-dynamic.mjs'
import { createJudgePool } from './ratchet-judge.mjs'
import { registerGuard } from './ratchet-guard.mjs'
import {
  bootstrap,
  compile,
  deduplicate,
  findRoot,
  ingest,
  ingestAuto,
  ingestBatch,
  ratifications,
  ratify,
  ratifyInteractively,
  review,
  status,
  submitReview,
  summariseProblems,
  verify,
} from './ratchet-ops.mjs'

/** Cordis function-plugin name; also the id a profile patch row targets. */
export const name = 'ratchet'

/**
 * Services requested before `apply` runs.
 *
 * `tools` only, deliberately. Cordis makes an injection a hard gate in both
 * directions (measured; see `docs/RATCHET-API-FACTS.md` §3.3): declaring a name no
 * service registers leaves the entry pending and fails the whole boot, while
 * reading `ctx.<name>` without declaring it throws. The static layer must keep
 * working in a base-only composition, so the subagents runtime is reached
 * opportunistically through `ctx.get('subagents')` at call time — and its absence
 * is the degraded path rather than a boot failure.
 */
export const inject = ['tools']

/**
 * The service name the subagent runtime registers under.
 *
 * **Plural.** The row id is `subagent` and the package's prose says `subagents`
 * while the constructor calls `super(ctx, "subagents")`. Asking for the singular
 * returns `undefined` and produced a completely false "the runtime is
 * unreachable" finding during API discovery, so the name lives in one constant
 * with this note attached rather than being spelled at each call site.
 */
export const SUBAGENTS_SERVICE = 'subagents'

/**
 * The service name the human-question channel registers under.
 *
 * Camel-case and plural, exactly as the service registers it (`super(ctx,
 * "userQuestions")`). Like the subagent runtime it is reached through
 * `ctx.get(name)` at call time rather than through `inject`, because declaring a
 * service an installation does not mount fails the whole boot — and a project
 * without a question channel can still compile, verify and report.
 */
export const USER_QUESTIONS_SERVICE = 'userQuestions'

/**
 * The service name the live agent registry registers under.
 *
 * Read for one fact only: whether the calling agent is a runtime ROOT. The
 * auto-review a compile triggers asks it before spawning a judge, so a judge that
 * itself compiles cannot start a review of its own (see `isRootCaller`).
 */
export const AGENTS_SERVICE = 'agents'

/**
 * The service name the slash-command registry registers under.
 *
 * Read for one capability: registering `/ratify`, the same operation as the
 * `ratchet_ratify` tool, reached without the model. A command handler runs host-side
 * and receives `invocation.agent`, so it can put the ratchet's own question to the
 * human directly — which a browser half cannot, because the question seam is
 * Agent-scoped. Reached through `ctx.get` at apply time rather than through `inject`,
 * for the same reason as the other optional services: a composition that mounts no
 * command registry must still compile and verify. `@deepseek-ai/dsh-base` mounts it,
 * so it is present in every profile this deployment ships.
 */
export const COMMANDS_SERVICE = 'commands'

export { PROBLEM_CODES }

/**
 * Resolves the project root for one tool call.
 *
 * The workspace comes from the session the call belongs to, never from the server's
 * launch directory: the harness is normally started from a home or app directory, so
 * searching upward from `process.cwd()` finds no manifest.
 *
 * @param exec - Tool-execution context supplied by the harness.
 * @returns `{ root, found }` where `root` is the session workspace even when no
 *   manifest was found above it — `ratchet_bootstrap` needs to know where to write,
 *   and a workspace is a better answer than nothing. `found` distinguishes the two
 *   cases for the operations that genuinely require a manifest.
 */
export function rootFor(exec) {
  const cwd = exec?.agent?.session?.header?.cwd
  if (typeof cwd !== 'string' || cwd.length === 0) return { root: null, found: false }
  const found = findRoot(cwd)
  return { root: found ?? cwd, found: found !== null }
}

/**
 * Registers the four ratchet tools.
 *
 * @param ctx - Cordis context; must expose `tools` (declared in `inject`).
 * @returns Nothing. Registrations are made inside `ctx.effect`, the disposal
 *   contract that lets a hot reload replace them instead of colliding with the
 *   registry's duplicate-name rule.
 */
export function apply(ctx) {
  // The guard is registered OUTSIDE the tool-registration effect, and on its own
  // effect: it is a different extension point (`tools.guard`), governs calls to
  // other plugins' tools, and must survive a failure to register any single tool.
  registerGuard(ctx, (exec) => rootFor(exec).root)

  // The consent service: the seam a NON-AGENT surface reaches the ratchet's own
  // question through. It is provided, never registered as a tool, so nothing an agent
  // can call reaches it — an agent-facing operation that accepted an answer is exactly
  // the second consent path the deployment refuses. `ctx.provide` throws when the name
  // is already registered in this scope (a second ratchet row, or a reload that has not
  // disposed the previous fiber), so the failure is reported on stderr and the tools are
  // still registered rather than the whole plugin failing.
  //
  // Its consents record their own channel (`adr-panel`) rather than the harness seam's,
  // and the channel is the SERVICE's, not an argument: a caller cannot ask to be recorded
  // as having come through the user-questions seam, because it did not.
  ctx.effect(() => {
    try {
      return ctx.provide(CONSENT_SERVICE, createConsentService())
    } catch (error) {
      process.stderr.write(`ratchet: cannot provide ${CONSENT_SERVICE}: ${String(error)}\n`)
      return undefined
    }
  }, `ratchet: provide ${CONSENT_SERVICE}`)

  // The decisions service: the seam a NON-AGENT surface reads a project's whole decision
  // state through. Like the consent service it is provided, never registered as a tool,
  // so nothing an agent can call reaches it — and, more importantly, there is exactly ONE
  // derivation of force, consent matching and the ratify queue, which is this ratchet's.
  // A UI that re-derived those would be a second implementation of one truth, and it
  // would drift. `ctx.provide` throws when the name is already registered in this scope,
  // so the failure is reported on stderr and the tools are still registered.
  ctx.effect(() => {
    try {
      return ctx.provide(DECISIONS_SERVICE, createDecisionsService())
    } catch (error) {
      process.stderr.write(`ratchet: cannot provide ${DECISIONS_SERVICE}: ${String(error)}\n`)
      return undefined
    }
  }, `ratchet: provide ${DECISIONS_SERVICE}`)

  // The resolve service: the seam a NON-AGENT surface reaches the ratchet's own resolve
  // plan, resolver prompt and refusal recording through. Provided, never a tool: a tool
  // that accepted a resolve request would be a second way to start one, and the plan and
  // the prompt are the ratchet's text, not the transport's. `ctx.provide` throws when the
  // name is already registered in this scope, so the failure is reported on stderr and the
  // tools are still registered.
  ctx.effect(() => {
    try {
      return ctx.provide(RESOLVE_SERVICE, createResolveService())
    } catch (error) {
      process.stderr.write(`ratchet: cannot provide ${RESOLVE_SERVICE}: ${String(error)}\n`)
      return undefined
    }
  }, `ratchet: provide ${RESOLVE_SERVICE}`)

  ctx.effect(() => {
    const disposers = []

    /** Registers one tool, reporting a failure instead of taking the tree down. */
    const register = (definition) => {
      try {
        disposers.push(ctx.tools.register(definition))
      } catch (error) {
        process.stderr.write(`ratchet: cannot register ${definition.name}: ${String(error)}\n`)
      }
    }

    /**
     * The canonical output declaration.
     *
     * `{ type: 'json' }` is the DSL's unconstrained lossless-JSON node. It is
     * available here only because these are `defineTool` definitions; a raw
     * registered schema is validated as JSON Schema and rejects it.
     */
    const output = () => ({
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    })

    /**
     * Runs one operation that requires an existing project.
     *
     * Async because verification is: a law may declare a `command` check, and awaiting
     * here is what lets the tool return the result rather than a promise. The runner
     * is deliberately NOT supplied — a tool an agent calls mid-edit must not spawn
     * processes the user did not ask for, so a command check surfaces as
     * `checksPending` and the answer says so.
     */
    const withRoot = async (exec, operation, explicitRoot = null) => {
      // An explicit `root` wins over the session workspace. Measured on a real task: an
      // agent working in another project called `ratchet_status`, which resolved the
      // SESSION workspace — the kit — and answered with the kit's state
      // (`VERIFY_NOT_RUN`) for a project that was verified and green. Every tool answers
      // about a project, so the caller must be able to say which one; the resolved root
      // is in every result either way.
      const { root, found } =
        typeof explicitRoot === 'string' && explicitRoot.length > 0
          ? { root: resolve(explicitRoot), found: true }
          : rootFor(exec)
      if (root === null || !found) {
        const problems = [
          {
            code: 'MANIFEST_MISSING',
            severity: 'error',
            subject: null,
            message:
              root === null
                ? `this session has no workspace directory, so there is nowhere to look for ${MANIFEST_PATH}`
                : `no ${MANIFEST_PATH} found in ${root} or any parent, so this project declares no decisions`,
          },
        ]
        return {
          ok: false,
          stage: 'resolve-root',
          reason: problems[0].message,
          fix: 'call ratchet_bootstrap in preview mode to see the manifest and directories it would create, then apply it',
          problems,
          summary: summariseProblems(problems),
        }
      }
      return operation(root)
    }

    /**
     * Puts one quiz to the human through the harness user-questions channel.
     *
     * Reached opportunistically, like the subagent runtime: a deployment with no
     * question channel is a deployment where ratification cannot happen, which is a
     * fact to report rather than a boot to fail. Every failure mode is returned as a
     * value — no service, no agent to route through, a service with no `ask`, a
     * thrown ask (the seam refuses a caller that is not the live root agent, which
     * is exactly the case of a subagent trying to obtain consent for its parent's
     * decision, and that refusal must not be mistaken for consent).
     *
     * `null` means "this call has no channel", which the operation turns into a
     * prepared quiz and an actionable next step rather than an exception.
     *
     * @param exec - Tool-execution context, for the agent and the abort signal.
     * @returns An `askHuman` for the ratification operation, or `null`.
     */
    const humanChannel = (exec) => {
      const service = ctx.get(USER_QUESTIONS_SERVICE)
      const agent = exec?.agent
      if (service === undefined || service === null || typeof service.ask !== 'function' || agent === undefined) {
        return null
      }
      return async (quiz) => {
        try {
          const answer = await service.ask({
            agent,
            questions: quiz.questions,
            ...(exec?.signal === undefined ? {} : { signal: exec.signal }),
          })
          return { kind: 'ok', answer }
        } catch (error) {
          return { kind: 'unavailable', reason: String(error) }
        }
      }
    }

    /**
     * Runs `/ratify [<adr-id> …]` for the session that invoked it.
     *
     * The same operation as the `ratchet_ratify` tool, and deliberately the same code
     * path: it builds the quiz with `ratifyInteractively`, asks it through the single
     * question channel `humanChannel` reaches, and returns the canonical result. The
     * only thing a command adds is that it is reached without a model turn, because a
     * command handler is host-side and already holds the session's agent.
     *
     * A handler that throws is a handler whose failure the registry reports as
     * `kind: 'error'`; this one catches its own failures so the message names what
     * happened rather than the exception's shape.
     *
     * @param invocation - The command invocation: `agent`, `rawInput`, `signal`.
     * @returns A `CommandResult` — `success` when a decision was ratified or the
     *   human declined deliberately, `error` when there was nothing to ask, the
     *   channel was unreachable, or the answer could not be read. A command that
     *   cannot put its question never reports success.
     */
    const ratifyFromCommand = async (invocation) => {
      const exec = { agent: invocation?.agent, signal: invocation?.signal }
      const { root, found } = rootFor(exec)
      if (root === null || !found) {
        return {
          kind: 'error',
          text:
            root === null
              ? 'the /ratify command has no session workspace, so there is no project to ratify in'
              : `no ${MANIFEST_PATH} was found above the session workspace, so this project declares no decisions to ratify`,
        }
      }

      try {
        const result = await ratifyInteractively({
          root,
          ids: parseRatifyIds(invocation?.rawInput),
          askedBy: askedByFor(exec),
          askHuman: humanChannel(exec),
          budget: createWorkBudget(),
        })
        return { kind: ratifyOutcomeKind(result), text: renderRatifyOutcome(result) }
      } catch (error) {
        return {
          kind: 'error',
          text: `the ratification did not settle: ${String(error)}. Nothing was written for a call that threw, so no consent was minted.`,
        }
      }
    }

    /**
     * Puts a freshly ingested decision to the human in the same call, when asked.
     *
     * This is the grill entry: the agent grills the human, writes the reasoning to a
     * source, and asks the ratchet to record the decision — and the human consents in
     * the same flow, through the one question channel. It is a third ENTRY, never a
     * third channel: the quiz is the ratchet's own and no argument accepts an answer.
     * It is also the ONE entry whose question is rendered in the Conversation rather
     * than in the decision panel, because a grill is a conversation the human is already
     * having and the question blocks it until it is answered.
     *
     * It FAILS CLOSED. A record that was not written is not ratified, because there is
     * nothing on disk to consent to and the approval would bind a text only the caller
     * has seen; a missing channel or an unreadable answer mints nothing. The proposal
     * and the reason are returned instead, so the caller can put the question itself.
     *
     * @param ingested - The `ingest` operation's result.
     * @param context - `{ root, exec }` — the project and the call whose agent is asked.
     * @returns The ingestion result, plus a `ratify` field holding the canonical
     *   ratification result and a `ratifyOutcome` string rendering it. When the record
     *   was not written, `ratify` carries `{ attempted: false, reason }` and nothing is
     *   minted.
     */
    const ratifyIngested = async (ingested, { root, exec }) => {
      const id = ingested?.adr?.id
      if (typeof id !== 'string' || id.length === 0 || ingested?.written === null || ingested?.written === undefined) {
        return {
          ...ingested,
          ratify: {
            attempted: false,
            reason:
              'the record was not written, so there is nothing to ratify: call again with write enabled, then the question can be put to the human',
          },
        }
      }
      const result = await ratifyInteractively({
        root,
        ids: [id],
        askedBy: askedByFor(exec),
        askHuman: humanChannel(exec),
        // A grilling session is the one entry whose question belongs in the Conversation:
        // the agent is talking to the human there, the human is expected to answer before
        // the session moves on, and making them leave the conversation to find the decision
        // panel is the wrong trade. Every other entry asks with the panel's presentation
        // intent, so the panel renders the question itself and the Conversation carries a
        // pointer to it instead of a second copy.
        present: 'chat',
        budget: createWorkBudget(),
      })
      return {
        ...ingested,
        ratify: result,
        ratified: result.ratified ?? [],
        ratifyOutcome: renderRatifyOutcome(result),
      }
    }

    /**
     * The per-session judge pool. ONE durable judge child serves every review and ingestion a
     * session's ROOT agent runs, instead of a fresh `spawn` run per job that is disposed in
     * `finally`. The pool owns serialization, reuse across the corpus changes the ratchet
     * exists to make, replacement of a child whose creation or delivery failed, and
     * turn-scoped cancellation; the lifecycle contract is documented in `ratchet-judge.mjs`.
     *
     * Reached opportunistically through `ctx.get`, never through `inject` (see
     * SUBAGENTS_SERVICE): a composition without the subagents runtime must still compile and
     * verify, so availability is decided per call by `judgeSpawner`, which returns `null`
     * exactly as it did before — and now also for a caller that is not a live root.
     */
    const judgePool = createJudgePool({
      runtimeOf: () => ctx.get(SUBAGENTS_SERVICE),
      agentsOf: () => ctx.get(AGENTS_SERVICE),
      log: (event) => {
        // Bounded lifecycle logging only: one line per create/recreate/release, never one per
        // turn, so a long session cannot flood the log. `ctx.logger` is optional in a base
        // composition, so the fallback is silent.
        try {
          ctx.logger?.info?.(`ratchet.judge ${JSON.stringify(event)}`)
        } catch {
          /* logging is diagnostics */
        }
      },
    })

    /**
     * Builds the judge call a review or an ingestion runs on.
     *
     * A judge is created only for a live ROOT agent. The harness authorizes a continuable
     * message only between a parent and its own direct child, so a subagent cannot drive the
     * root session's judge; letting it build one of its own made the number of judge children
     * follow the number of callers rather than the number of law sets reviewed. A non-root
     * caller gets `null` and takes the degraded self-review path, which returns the prompt for
     * the caller to answer or hand to its parent. This is also the recursion guard: a spawned
     * judge runs `ratchet_review` from a non-root agent, and must not start a review of its own.
     *
     * @param exec - Tool-execution context; its agent is the judge's parent and its signal
     *   lets a cancelled tool call cancel ONLY that call's turn (the shared judge survives).
     * @returns An async `(prompt, outputSchema, staticPrompt)` returning the judge's result,
     *   or `null` when this call cannot reach a judge. `staticPrompt` is the byte prefix of
     *   `prompt` that does not change between calls; the pool delivers it once, when the
     *   judge child is created, and sends only the material after it on later calls. It is
     *   optional: when absent (or not a prefix) the full prompt is sent every call.
     */
    const judgeSpawner = (exec) => {
      const runtime = ctx.get(SUBAGENTS_SERVICE)
      const agent = exec?.agent
      if (runtime === undefined || agent === undefined) return null
      if (!isRootCaller(exec)) return null
      return (prompt, outputSchema, staticPrompt) =>
        judgePool.judge({ parent: agent, signal: exec.signal, prompt, outputSchema, staticPrompt })
    }

    /**
     * Reports whether one call is made by a live ROOT agent.
     *
     * Every judge is gated on this, and the guard is not cosmetic: a spawned judge is a full
     * agent, so a judge that ran `ratchet_review` would spawn another judge, and repeat for as
     * long as the models kept cooperating. The subagent runtime owns the fact "this agent is a
     * root"; asking it is exact where an in-process flag would be a guess. A composition
     * without the registry answers `false`, so the conservative outcome — no judge — is also
     * the one that cannot recurse, and every non-root caller takes the degraded self-review
     * path that returns the prompt instead of an answer.
     *
     * @param exec - Tool-execution context.
     * @returns `true` only when the registry confirms this agent is a runtime root.
     */
    const isRootCaller = (exec) => {
      const agents = ctx.get(AGENTS_SERVICE)
      const agent = exec?.agent
      if (agents === undefined || typeof agents.roots !== 'function' || agent === undefined) return false
      try {
        return agents.roots().includes(agent)
      } catch {
        return false
      }
    }

    register(
      defineTool({
        name: 'ratchet_status',
        description:
          'Report the ratchet state of this project without changing it: whether a manifest is present and ' +
          'ratchet-enabled, how many ADRs are active or proposed, the current spec hash, whether the ' +
          'persisted spec bundle is out of date, and whether the code has been verified against the laws ' +
          'currently in force. Call this first when you do not know whether a project uses the ratchet. ' +
          'It reports VERIFY_NOT_RUN when no verification covers the current laws, which is the difference ' +
          'between "checked and clean" and "never checked".',
        parameters: {
          root: {
            type: 'string',
            description:
              'Absolute path of the project to report on. Defaults to the session workspace, whose resolved path is in the result as `root` — pass this when you are working in a project other than the one the session was opened on, because the tools otherwise answer for the session workspace.',
          },
        },
        output: output(),
        execute(args, exec) {
          // The in-process path carries a conservative work budget: this tool runs on the
          // harness's single event loop, so a 500 MB file read or a catastrophic regex would
          // freeze every session in the process. An exhausted budget is REPORTED
          // (`WORK_BUDGET_EXCEEDED`, `CODE_FILE_TOO_LARGE`) and returns no verdict; the CLI,
          // which has its own process, passes no budget and reads everything.
          return withRoot(exec, (root) => status(root, { budget: createWorkBudget() }), args.root)
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_bootstrap',
        description:
          'Create the manifest and directory skeleton a project needs before the ratchet can do anything. ' +
          'Use mode "preview" first: it returns the manifest text and the exact paths that would be ' +
          'created, and writes nothing. Use mode "apply" to write them. Existing files are never ' +
          'overwritten unless force is true, and every skipped path is reported.',
        parameters: {
          mode: {
            type: 'string',
            enum: ['preview', 'apply'],
            description: 'preview (default) reports the plan; apply writes it.',
          },
          name: { type: 'string', description: 'Project name recorded in the manifest.' },
          mainPaths: { type: 'string', description: 'Glob for the default zone, e.g. "src/**".' },
          force: { type: 'boolean', description: 'Overwrite existing files. Default false.' },
        },
        output: output(),
        execute(args, exec) {
          const mode = args.mode === 'apply' ? 'apply' : 'preview'
          // Bootstrap is the one operation that must work when nothing else does:
          // it takes the session workspace directly, because the manifest it is
          // about to create is the thing `withRoot` would have required.
          const { root } = rootFor(exec)
          return Promise.resolve(
            bootstrap({
              root,
              mode,
              name: args.name,
              mainPaths: args.mainPaths,
              force: args.force === true,
            }),
          )
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_compile',
        description:
          'Compile the active architecture decision records into the laws the project enforces, and report ' +
          'every structural, authority and collision problem the corpus contains. Call this after adding or ' +
          'amending an ADR, and before implementing anything a decision governs. It always records its ' +
          'report and the machine-readable spec bundle; pass write: true to also emit the generated spec ' +
          'documents. It reports SPEC_HASH_MISMATCH when a generated document was edited by hand. It runs no ' +
          'model: whether a corpus review has read the law set now in force is reported as the ' +
          '`contradictionReview` field, and measuring meaning is ratchet_review, which is the only call that ' +
          'spawns a judge.',
        parameters: {
          write: {
            type: 'boolean',
            description:
              'Also write the generated spec documents under the manifest specs directory. Default false — ' +
              'the report and the spec bundle are recorded either way.',
          },
        },
        output: output(),
        execute(args, exec) {
          return withRoot(
            exec,
            async (root) => {
              // A conservative in-process budget, for the same reason as `ratchet_status`:
              // compile reads every ADR and the source each one cites, and a 500 MB record
              // blocked the harness event loop for about three seconds. The CLI passes none.
              // Nothing here reaches a judge: the deterministic verdict is returned immediately
              // and the caller reads `contradictionReview.stale` as the fact it is.
              return compile({ root, write: args.write === true, budget: createWorkBudget() })
            },
            args.root,
          )
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_verify',
        description:
          'Verify the codebase against the compiled laws: required and forbidden files, globs, text and ' +
          'dependencies, and zone path boundaries. This is deterministic — it asks no model — and it ' +
          'writes reports/ratchet/verify-report.json, recording the spec hash AND the code hash it judged. ' +
          'Every problem names the law, the file and the evidence, and a check that could not be evaluated ' +
          'is reported rather than passed. WHAT THIS TOOL CANNOT DO, so "done" is not claimed on its word: ' +
          'it supplies no command runner, so every `command` check comes back pending and the result is ' +
          'VERIFY_INCOMPLETE with ok:false however healthy the code is. A law whose enforcement is a ' +
          'command (a test suite, a lint, a script) therefore makes this tool a report and not a verdict — ' +
          '`node plugins/ratchet/ratchet-cli.mjs verify --root <project>` in a shell is the gate, and only ' +
          'that can return ok. Use this tool to see which laws exist and which filesystem checks hold.',
        parameters: {
          root: {
            type: 'string',
            description:
              'Absolute path of the project to verify. Defaults to the session workspace, whose resolved path is in the result as `root` — pass this when the project you changed is not the one the session was opened on.',
          },
        },
        output: output(),
        execute(args, exec) {
          // Same in-process budget as the compile: a text law over a data directory reads
          // every file it selects, and a 500 MB one blocked the event loop for 15 seconds.
          return withRoot(exec, (root) => verify({ root, budget: createWorkBudget() }), args.root)
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_ratify',
        description:
          'Put PROPOSED decisions to the human and record their consent. This is the only way a decision an agent ' +
          'proposed enters force THROUGH THE RATCHET: the ratchet asks the human one question per waiting record, ' +
          'showing that record\'s own text, and writes an approval ADR only when the answer selects that question\'s ' +
          'approve label — anything else is unreadable, is re-asked once in a different shape, and mints nothing. ' +
          'The consent is bound to a content hash of the text the human was shown, so editing an approved record — ' +
          'or editing it while the question is open — voids it until it is ratified again. There is deliberately NO ' +
          'argument that accepts an answer you composed: a consent this ratchet cannot check against a question it ' +
          'asked is a consent it cannot tell from a sentence an agent typed. The question does not appear as a chat ' +
          'quiz: it declares the ADR panel\'s presentation intent, so a client that has the panel puts the question in ' +
          'the decision window and the Conversation carries only a pointer to it — and if no client claims it, the ' +
          'harness\'s own card asks it in the Conversation, so it is never unanswerable. The one exception is a ' +
          'grilling session, which asks for the Conversation on purpose because the human is already talking there. ' +
          'It is not the only way a file can ' +
          'reach the corpus: a record whose frontmatter says `authority: human` self-activates, and a hand-written ' +
          'approval that reproduces the ratification block correctly is indistinguishable from this one — nothing ' +
          'in a file-based mechanism can tell them apart, so a human reading the diff is the check. If the human ' +
          'channel is unavailable here, the result says so and nothing is written.',
        parameters: {
          ids: {
            type: 'string',
            description:
              'Comma-separated ADR ids to ratify, e.g. "0001,0007". Default: every decision waiting for a human.',
          },
          root: {
            type: 'string',
            description:
              'Absolute path of the project whose decisions to put to the human. Defaults to the session workspace. Pass it when the record waiting for a human lives in another project: the question is about that project\'s text, and the approval is written into that project.',
          },
        },
        output: output(),
        execute(args, exec) {
          // An explicit `root` wins over the session workspace, for the same reason the read
          // side needs it: a session opened on one project could not put another project's
          // record to the human at all, so the only ways to approve that record were to open
          // a second session or to hand-write an approval — and a hand-written approval is
          // indistinguishable from a forged one. Measured: an agent working in a governed
          // game project could not ratify its own proposed record from the kit's session.
          const { root, found } =
            typeof args.root === 'string' && args.root.length > 0
              ? { root: resolve(args.root), found: true }
              : rootFor(exec)
          if (root === null || !found) {
            const problems = [
              {
                code: 'MANIFEST_MISSING',
                severity: 'error',
                subject: null,
                message:
                  root === null
                    ? `this session has no workspace directory, so there is nowhere to look for ${MANIFEST_PATH}`
                    : `no ${MANIFEST_PATH} found in ${root} or any parent, so this project declares no decisions to ratify`,
              },
            ]
            return Promise.resolve({
              ok: false,
              stage: 'ratify',
              reason: problems[0].message,
              problems,
              summary: summariseProblems(problems),
            })
          }

          const ids =
            typeof args.ids === 'string' && args.ids.trim().length > 0
              ? args.ids.split(',').map((entry) => entry.trim()).filter((entry) => entry.length > 0)
              : null
          const askedBy = askedByFor(exec)

          // The question/answer/re-ask sequence is the operation's, so a probe can
          // drive the production path against a real channel and a test can drive it
          // with a literal answer. This adapter contributes only the channel — and
          // when there is none, the operation reports that rather than accepting an
          // answer from the model instead of the human.
          return ratifyInteractively({ root, ids, askedBy, askHuman: humanChannel(exec), budget: createWorkBudget() })
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_review',
        description:
          'Ask an INDEPENDENT judge agent whether something respects the project\'s decisions in meaning ' +
          'rather than in letter — the questions no static check can decide. Use it for a proposed ' +
          'decision, a code change, a conflict the compiler flagged, or to explain a violation. This is ' +
          'ADVISORY for everything except a CONTRADICTION: a finding that the change contradicts a decision in ' +
          'force in meaning — an error of kind semantic_violation or intent_violation naming a law — is recorded ' +
          'and the review DECLINES, and the write guard refuses writes in the zones that law governs until the ' +
          'change is fixed, the judged record is edited, or a human decides. Everything else it reports never ' +
          'changes whether work is done, and `ratchet_verify` remains the gate. ' +
          'Pass `verdict` instead of a job to file your own answer when no judge could be spawned. ' +
          'Findings that cite a law or ADR which does not exist are reported as unusable rather than ' +
          'passed on.',
        parameters: {
          job: {
            type: 'string',
            enum: Object.keys(REVIEW_JOBS),
            description:
              'What to review: review_corpus, review_change, review_proposal, review_conflict, ' +
              'explain_violation, grill_preparation, or review_duplicates — the last being the ADVISORY ' +
              'duplicate report: decisions that state one constraint in different words, which no text ' +
              'comparison can see. Default review_corpus.',
          },
          change: { type: 'string', description: 'The proposed change or diff to review.' },
          proposal: { type: 'string', description: 'The proposed ADR text, for review_proposal.' },
          source: { type: 'string', description: 'The raw source the proposal came from.' },
          conflict: { type: 'string', description: 'The conflict to adjudicate, for review_conflict.' },
          violation: { type: 'string', description: 'The static violation to explain.' },
          question: { type: 'string', description: 'An extra question for the judge.' },
          verdict: {
            type: 'json',
            description:
              'Your own verdict, for the degraded path: {ok, findings:[{severity, kind, explanation, ' +
              'lawId?, sourceAdr?, suggestedAction?}]}. Used when you answered the prompt yourself.',
          },
        },
        output: output(),
        execute(args, exec) {
          const resolved = rootFor(exec)
          const job = typeof args.job === 'string' && args.job.length > 0 ? args.job : 'review_corpus'

          // Filing a verdict the caller produced. Validated exactly like a spawned
          // judge's, because the argument for checking a model's output applies at
          // least as strongly to output a model wrote by hand.
          if (args.verdict !== undefined && args.verdict !== null) {
            if (!resolved.found) {
              return Promise.resolve({
                ok: false,
                stage: 'review',
                advisory: true,
                reason: `no ${MANIFEST_PATH} found, so there are no laws to check the verdict against`,
              })
            }
            return Promise.resolve(
              submitReview({
                root: resolved.root,
                job,
                verdict: args.verdict,
                record: true,
                change: args.change ?? null,
                proposal: args.proposal ?? null,
                source: args.source ?? null,
              }),
            )
          }

          if (!resolved.found) {
            return Promise.resolve({
              ok: false,
              stage: 'review',
              advisory: true,
              reason: `no ${MANIFEST_PATH} found, so there are no decisions to review against`,
            })
          }

          // Reached opportunistically, never injected: see SUBAGENTS_SERVICE.
          return review({
            root: resolved.root,
            job,
            change: args.change ?? null,
            proposal: args.proposal ?? null,
            source: args.source ?? null,
            conflict: args.conflict ?? null,
            violation: args.violation ?? null,
            question: args.question ?? null,
            spawnJudge: judgeSpawner(exec),
            record: true,
          })
        },
      }),
    )

    register(
      defineTool({
        name: 'ratchet_ingest_source',
        description:
          'Turn a raw source of reasoning — a grilling transcript, a task brief, an investigation note — into a ' +
          'PROPOSED architecture decision record. It reads the source, has a judge extract the decision, its ' +
          'reasoning and the checks the decision implies, and verifies that every sentence the judge attributes to ' +
          'the source actually appears there: a justification or a check whose quoted basis is not in the source is ' +
          'refused or dropped rather than recorded. When the source states a decision without stating why, it returns ' +
          'INSUFFICIENT_REASONING and asks for the reasoning to be captured first. Nothing is written unless write is ' +
          'true, and the record it produces is always `proposed`: a human decides whether it becomes law, through ' +
          'ratchet_ratify. Pass `ingest` to file an answer you obtained yourself when no judge could be spawned. Pass ' +
          '`ratify` to end a grill session with the ratchet\'s own question: once the record is written, the same ' +
          'call puts it to the human through the question channel and records the approval.',
        parameters: {
          source: {
            type: 'string',
            description: 'Repository-relative path of the source file to ingest, e.g. docs/ratchet/sources/x.md.',
          },
          write: {
            type: 'boolean',
            description:
              'Write the generated ADR under the decisions directory. Default false — the record is returned ' +
              'for review first, and it is only written if it compiles.',
          },
          ingest: {
            type: 'json',
            description:
              'A result you produced for this source, in the shape the returned prompt asks for. It is validated ' +
              'exactly like a spawned judge\'s result, provenance checks included; use it when no judge could be spawned.',
          },
          ratify: {
            type: 'boolean',
            description:
              'After writing the record, put it to the human as the ratchet\'s own question in the same call — the ' +
              'grill-session entry to consent, and never a second channel: no value here accepts an answer. Fails ' +
              'closed, so nothing is approved when the record was not written, when no question channel is ' +
              'available, or when the answer cannot be read. Default false.',
          },
        },
        output: output(),
        async execute(args, exec) {
          const resolved = rootFor(exec)
          const sourcePath = typeof args.source === 'string' && args.source.length > 0 ? args.source : null
          if (sourcePath === null) {
            return {
              ok: false,
              stage: 'ingest',
              reason: 'ingestion needs the path of a source file holding the reasoning to record',
            }
          }
          if (!resolved.found) {
            return {
              ok: false,
              stage: 'ingest',
              reason: `no ${MANIFEST_PATH} found, so there is no decisions directory or zone list to record against; call ratchet_bootstrap first`,
            }
          }

          const ingested = await ingest({
            root: resolved.root,
            sourcePath,
            write: args.write === true,
            submitted: args.ingest ?? null,
            spawnJudge: judgeSpawner(exec),
            budget: createWorkBudget(),
          })
          if (args.ratify !== true) return ingested
          return ratifyIngested(ingested, { root: resolved.root, exec })
        },
      }),
    )

    // The batch extractor: a surface of its OWN, not a mode of the tool above. The two carry
    // different guarantees — a single ingestion proves every sentence the judge attributes to
    // the source is in it, a batch proves only that each decision cites a span that is — and
    // one tool whose guarantees depend on an argument is a tool whose caller cannot tell
    // which one they got. It is also the reason the consent-surface check scans every
    // registered tool rather than a list: a second ingestion surface has to be inspected for
    // an answer-shaped argument without anybody remembering to add it there.
    register(
      defineTool({
        name: 'ratchet_ingest_batch',
        description:
          'Extract MANY proposed architecture decision records from one source in one call, for a document ' +
          'that states several decisions. Every decision must carry a verbatim span from the source, and this ' +
          'tool locates that span in the source itself before writing the record: a decision whose span it ' +
          'cannot find is refused ALONE, and the other decisions in the batch are still written. The batch is ' +
          'capped, and a batch above the cap is refused together with the heading boundaries the tool found, so ' +
          'a large document is split mechanically rather than by judgement. Every record it writes is ' +
          '`proposed` — no batch puts a decision into force, and a human ratifies through ratchet_ratify. ' +
          'This is deliberately a separate tool from ratchet_ingest_source, whose stronger per-sentence ' +
          'attribution guarantee is unchanged. Pass `ingest` to file an answer you obtained yourself when no ' +
          'judge could be spawned.',
        parameters: {
          source: {
            type: 'string',
            description: 'Repository-relative path of the source file to extract decisions from.',
          },
          write: {
            type: 'boolean',
            description:
              'Write the generated records under the decisions directory. Default false — the records are ' +
              'returned for review first, and each one is written only if it compiles.',
          },
          ingest: {
            type: 'json',
            description:
              'A batch result you produced for this source, in the shape the returned prompt asks for: ' +
              '`{ decisions: [{ span, title, decision, reasoning, reasoningBasis, context, contextBasis, … }] }`. ' +
              'Validated exactly like a spawned judge\'s result, provenance checks included; use it when no ' +
              'judge could be spawned.',
          },
        },
        output: output(),
        async execute(args, exec) {
          const resolved = rootFor(exec)
          const sourcePath = typeof args.source === 'string' && args.source.length > 0 ? args.source : null
          if (sourcePath === null) {
            return {
              ok: false,
              stage: 'ingest-batch',
              reason: 'batch extraction needs the path of a source file holding the reasoning to record',
            }
          }
          if (!resolved.found) {
            return {
              ok: false,
              stage: 'ingest-batch',
              reason: `no ${MANIFEST_PATH} found, so there is no decisions directory or zone list to record against; call ratchet_bootstrap first`,
            }
          }
          return ingestBatch({
            root: resolved.root,
            sourcePath,
            write: args.write === true,
            submitted: args.ingest ?? null,
            spawnJudge: judgeSpawner(exec),
            budget: createWorkBudget(),
          })
        },
      }),
    )

    // The entry point a developer actually calls. The two extractors above are still
    // registered and are deliberately unchanged — each carries a documented guarantee, and a
    // caller who needs the stronger per-sentence attribution of `ratchet_ingest_source`
    // should still be able to ask for it by name. What this adds is that nobody has to: it
    // measures the document, splits it on its headings when the cap requires it, drives one
    // judge call per chunk, validates each answer against its own chunk, and reports what it
    // did. A document the cap can hold is one chunk and one call.
    register(
      defineTool({
        name: 'ratchet_ingest',
        description:
          'Turn a document that states one or MANY decisions into PROPOSED architecture decision records, ' +
          'choosing the extraction path itself. It splits a source too large for one call on its HEADINGS ' +
          '(mechanically, never by judgement), runs one extraction per chunk, and validates every decision ' +
          'against the text it was drawn from: a decision whose cited span cannot be located is refused ALONE ' +
          'and the rest of its chunk still lands. Every record it writes is `proposed` — nothing here puts a ' +
          'decision into force, and a human ratifies through ratchet_ratify. It reports the chunk boundaries, ' +
          'what each chunk produced and what it refused, so the split is visible rather than implied. Pass ' +
          '`ingest` to file answers you obtained yourself — a single verdict object for a one-chunk source, or ' +
          'an array of one verdict per chunk — which is how a session that cannot spawn a judge still completes ' +
          'the ingestion. Use `ratchet_ingest_source` instead when you specifically want its stronger ' +
          'per-sentence attribution check, and `ratchet_ingest_batch` when you want to drive the cap and the ' +
          'split yourself.',
        parameters: {
          source: {
            type: 'string',
            description: 'Repository-relative path of the source file to extract decisions from.',
          },
          write: {
            type: 'boolean',
            description:
              'Write the generated records under the decisions directory. Default false — the records are ' +
              'returned for review first, and each one is written only if it compiles.',
          },
          ingest: {
            type: 'json',
            description:
              'Answers you obtained yourself, when no judge could be spawned: a single verdict object ' +
              '(`{ decisions: [{ span, title, decision, reasoning, reasoningBasis, context, contextBasis, … }] }`) ' +
              'for a one-chunk source, or an array of one such object per chunk in order. Each is validated ' +
              'exactly like a spawned judge\'s result, provenance checks included; a `null` entry leaves that ' +
              'chunk unanswered.',
          },
        },
        output: output(),
        async execute(args, exec) {
          const resolved = rootFor(exec)
          const sourcePath = typeof args.source === 'string' && args.source.length > 0 ? args.source : null
          if (sourcePath === null) {
            return {
              ok: false,
              stage: 'ingest-auto',
              reason: 'ingestion needs the path of a source file holding the reasoning to record',
            }
          }
          if (!resolved.found) {
            return {
              ok: false,
              stage: 'ingest-auto',
              reason: `no ${MANIFEST_PATH} found, so there is no decisions directory or zone list to record against; call ratchet_bootstrap first`,
            }
          }
          return ingestAuto({
            root: resolved.root,
            sourcePath,
            write: args.write === true,
            submitted: args.ingest ?? null,
            spawnJudge: judgeSpawner(exec),
            budget: createWorkBudget(),
          })
        },
      }),
    )

    // The drafting half of duplicate detection. `scripts/check-duplicate-decisions.mjs` reports
    // and fails the gate; this turns each report into a `proposed` resolution a human can
    // ratify. It runs no model — the two rules are decidable from the files — so there is no
    // `ingest`-style answer argument here, and nothing it writes is in force.
    register(
      defineTool({
        name: 'ratchet_deduplicate',
        description:
          'Detect the duplicate decisions a machine can decide and DRAFT the resolution that settles each ' +
          'one, so the only remaining act is a human ratification. Two rules are decidable from the files: one ' +
          'law statement declared under two different law ids, and one source cited by two records that also ' +
          'declare a law in common. For each it drafts an ordinary `proposed` record carrying ' +
          '`resolves: [loser, winner]` and an `op: remove` for the duplicated law — the surgical settlement, ' +
          'which withdraws the one law and leaves the rest of that record governing. It writes no approval and ' +
          'puts nothing into force: deleting a draft is how it is declined. A finding it cannot draft (a ' +
          'humanOnly zone, a terminal record, no shared law id) is reported with its reason rather than guessed ' +
          'at. The deterministic command keeps its own exit code and never runs a judge.',
        parameters: {
          write: {
            type: 'boolean',
            description:
              'Write each drafted resolution under the decisions directory. Default false — the drafts are ' +
              'returned as text for review first, and the file is the thing a human deletes to decline.',
          },
        },
        output: output(),
        async execute(args, exec) {
          const resolved = rootFor(exec)
          if (!resolved.found) {
            return {
              ok: false,
              stage: 'deduplicate',
              unusable: true,
              reason: `no ${MANIFEST_PATH} found, so there is no corpus to deduplicate`,
            }
          }
          return deduplicate({ root: resolved.root, write: args.write === true })
        },
      }),
    )

    // The `/ratify` command. It is the second ENTRY to the one consent channel, never a
    // second channel: the question is still the ratchet's and the answer is still derived
    // from the labels the human selected, so no argument here accepts an answer. Its value
    // over the tool is that a command is executed host-side without a model turn, so a UI
    // affordance that submits `/ratify <id>` reaches the human directly.
    //
    // Registered on the same effect as the tools, because it is the same adapter and the
    // same disposal contract: a hot reload replaces both registrations rather than
    // stacking a second command. The registration is caught separately, so a registry that
    // rejects the command cannot take the tools down with it.
    const commands = ctx.get(COMMANDS_SERVICE)
    if (commands !== null && commands !== undefined && typeof commands.register === 'function') {
      try {
        disposers.push(
          commands.register({
            name: 'ratify',
            description:
              'Put a proposed decision to the human as a question and record the answer; no argument accepts an answer, so the human answers the ratchet',
            input: { hint: '[<adr-id> …]' },
            handler: (invocation) => ratifyFromCommand(invocation),
          }),
        )
      } catch (error) {
        process.stderr.write(`ratchet: cannot register the /ratify command: ${String(error)}\n`)
      }
    }

    return () => {
      for (const dispose of disposers) dispose()
    }
  })
}

/**
 * Names who asked the human, for the approval's ratification block.
 *
 * The agent id IS the session id in this harness (`Agent.id` and `Session.id` are
 * the same branded value), so it identifies the conversation a consent was given
 * in. A call with no agent is recorded as `unattributed` rather than with an
 * invented name: an approval nobody can be asked about is a fact a reader should
 * see, and a plausible-looking substitute would hide it.
 *
 * @param exec - Tool-execution context.
 * @returns A non-empty string, either `session <id>` or `unattributed`.
 */
function askedByFor(exec) {
  const id = exec?.agent?.id
  if (typeof id !== 'string' || id.length === 0) return 'unattributed'
  // The harness already brands agent ids with a `session-` prefix, so prepending the
  // word produced `session session-<id>` in a durable record.
  return id.startsWith('session') ? id : `session ${id}`
}

/**
 * Parses the decision ids a `/ratify` invocation names.
 *
 * @param rawInput - The command's raw argument text, or any value.
 * @returns The ids named, or `null` when none were named — which the ratification
 *   operation reads as "every decision waiting for a human". Whitespace and commas
 *   both separate, so both `/ratify 0005 0007` and `/ratify 0005,0007` work. A
 *   non-string input yields `null` rather than throwing, because a command line is
 *   caller-supplied text.
 */
function parseRatifyIds(rawInput) {
  if (typeof rawInput !== 'string') return null
  const ids = rawInput
    .split(/[\s,]+/u)
    .map((entry) => entry.trim())
    .filter((entry) => entry.length > 0)
  return ids.length === 0 ? null : ids
}

/**
 * Reads the decision ids out of one field of a ratification result.
 *
 * @param entries - The result field: a list of id strings, of entries carrying an
 *   `id`, or any other value.
 * @returns The ids found, in order. Anything that carries no id is dropped, so a
 *   shape change in the operation renders as a shorter list rather than as
 *   `[object Object]` in a message a human reads.
 */
function ratifyIdsOf(entries) {
  if (!Array.isArray(entries)) return []
  return entries
    .map((entry) => (typeof entry === 'string' ? entry : entry?.id))
    .filter((id) => typeof id === 'string' && id.length > 0)
}

/**
 * Classifies a ratification result for the command registry.
 *
 * @param result - The canonical ratification result.
 * @returns `'success'` when a decision was ratified or the human declined
 *   deliberately — both are the command doing its job — and `'error'` for every
 *   outcome where the question was never put, could not be reached, or could not be
 *   read. A command must not report success for a consent it did not obtain.
 */
function ratifyOutcomeKind(result) {
  if (ratifyIdsOf(result?.ratified).length > 0) return 'success'
  if (ratifyIdsOf(result?.rejected).length > 0) return 'success'
  if (result?.nothingToRatify === true) return 'success'
  return 'error'
}

/**
 * Renders one ratification result as the text a command returns.
 *
 * @param result - The canonical ratification result.
 * @returns A single self-contained sentence (or two) naming what happened and
 *   whether anything was written. Never empty, so a command never settles with no
 *   explanation for the human who clicked it.
 */
function renderRatifyOutcome(result) {
  const ratified = ratifyIdsOf(result?.ratified)
  if (ratified.length > 0) {
    return `Ratified ${ratified.join(', ')}. The approval ADR and its transcript are written; compile and verify to see the new law set.`
  }
  if (result?.nothingToRatify === true) {
    return typeof result.message === 'string' && result.message.length > 0
      ? result.message
      : 'No decision is waiting for a human, so nothing was ratified.'
  }
  if (result?.askFailed === true) {
    return `Nothing was ratified: ${result.reason ?? 'the ratchet could not reach the human question channel'}. The question was never put to anyone.`
  }
  const rejected = ratifyIdsOf(result?.rejected)
  if (rejected.length > 0) {
    return `Not ratified: the human declined ${rejected.join(', ')}. Nothing was written, and the decisions stay proposed.`
  }
  const unreadable = ratifyIdsOf(result?.unreadable)
  if (unreadable.length > 0) {
    return `Nothing was ratified: the answer could not be read as approval or rejection for ${unreadable.join(', ')}.`
  }
  if (result?.needsAnswer === true) {
    return 'No decision is waiting for a human in this project, so no question was asked and nothing was written.'
  }
  const total = result?.summary?.total
  return typeof total === 'number' && total > 0
    ? `Nothing was ratified: ${String(total)} problem(s) stopped the operation.`
    : 'Nothing was ratified.'
}
