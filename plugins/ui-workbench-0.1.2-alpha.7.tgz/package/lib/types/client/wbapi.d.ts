/**
 * Typed fetch client for the workbench host wire (`/wb-api/*`), served by
 * `@deepseek-ai/dsh-host-web-workbench` on the same origin as the SPA.
 * @module @deepseek-ai/dsh-client-ui-workbench/client/wbapi
 */
import type { ChangedFileView, WbApiErrorCode, WorkspaceFileListing, WorkspaceReadFile, WorkspaceReviewDiff } from './types.ts';
/** Typed rejection of a /wb-api call. */
export declare class WbApiError extends Error {
    /** Stable machine-readable failure category from the host envelope. */
    readonly code: WbApiErrorCode;
    /**
     * @param code - host envelope code.
     * @param message - host envelope message.
     */
    constructor(code: WbApiErrorCode, message: string);
}
/** The workspace wire face. */
export declare const workspace: {
    /** Recursively list one workspace's files. */
    listFiles(workspaceId: string): Promise<WorkspaceFileListing>;
    /** Read one workspace file (bounded). */
    readFile(workspaceId: string, path: string): Promise<WorkspaceReadFile>;
    /**
     * Binary image preview URL for one workspace file (served by the host with
     * a content type from the image whitelist; oversized/non-image files fail
     * the request). Use directly as an `<img src>`.
     */
    imageUrl(workspaceId: string, path: string): string;
    /** List the workspace's current git changes. */
    changes(workspaceId: string): Promise<{
        items: ChangedFileView[];
    }>;
    /** Read one changed file's unified diff (bounded). */
    diff(workspaceId: string, path: string): Promise<WorkspaceReviewDiff>;
};
/** The system-integration wire face. */
export declare const system: {
    /** Open a workspace-relative path in the system file manager. */
    open(workspaceId: string, path?: string): Promise<{
        opened: true;
    }>;
    /** Report TUI file manager availability and the open command. */
    capabilities(): Promise<{
        tuiFileManager: string | null;
        editor: string | null;
        openCommand: string;
    }>;
};
/** Probe the host wire (health endpoint). */
export declare function health(): Promise<{
    ok: true;
}>;
//# sourceMappingURL=wbapi.d.ts.map