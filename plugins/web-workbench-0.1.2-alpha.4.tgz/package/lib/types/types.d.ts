/**
 * Wire types of the web workbench bridge. Browser-safe by construction: this
 * module imports nothing from node or any host package, so client plugins can
 * import it type-only (erased at bundle time) to type their fetch calls.
 * @module @deepseek-ai/dsh-host-web-workbench/types
 */
/** One entry of a workspace file listing. */
export interface WorkspaceFileEntry {
    /** Workspace-relative POSIX path; a directory path has no trailing slash. */
    path: string;
    /** Base name shown in a browser row. */
    name: string;
    /** Whether the entry is a directory rather than a regular file. */
    kind: 'file' | 'directory';
    /** File size in bytes; absent for directories. */
    size?: number;
}
/** Bounded recursive listing of one workspace. */
export interface WorkspaceFileListing {
    /** Entries in walk order (directories before files, each level sorted). */
    items: WorkspaceFileEntry[];
    /** Whether the host's configured entry cap cut the walk. */
    truncated: boolean;
}
/** Bounded readable content of one workspace file. */
export interface WorkspaceReadFile {
    /** UTF-8 file content, cut at the host's configured byte cap when large. */
    content: string;
    /** Whether the host's configured byte cap cut the file mid-stream. */
    truncated: boolean;
    /** Resolved workspace-relative path (POSIX spelling). */
    path: string;
}
/** Closed review status vocabulary (folded from git porcelain letters). */
export type WorkspaceReviewStatus = 'added' | 'modified' | 'deleted' | 'renamed' | 'copied' | 'untracked' | 'unmerged' | 'type-changed';
/** One changed file as the Review surface sees it. */
export interface ChangedFileView {
    /** Repository-relative path in POSIX spelling (git's own output form). */
    path: string;
    /** Folded porcelain status. */
    status: WorkspaceReviewStatus;
    /** Whether the change is staged in the index. */
    staged: boolean;
    /** Source path of a rename or copy, when git reported one. */
    oldPath?: string;
}
/** Bounded unified diff of one changed file. */
export interface WorkspaceReviewDiff {
    /** Unified diff text; an untracked file is presented as an all-additions diff. */
    diff: string;
    /** Whether the host's configured byte cap cut the diff mid-output. */
    truncated: boolean;
}
/** One live terminal session row. */
export interface TerminalSessionView {
    /** Opaque session id (string form; minted by the host). */
    sessionId: string;
    /** Working directory the shell was spawned under. */
    cwd: string;
    /** Whether the shell process is still running. */
    running: boolean;
}
/** System-integration capabilities the browser UI can offer. */
export interface SystemCapabilities {
    /** TUI file manager executable available on PATH (e.g. 'yazi'), or null. */
    tuiFileManager: string | null;
    /** Terminal text editor available on PATH ('micro'), or null. */
    editor: string | null;
    /** Command used to open paths in the system file manager. */
    openCommand: string;
}
/** Stable machine-readable failure category of a /wb-api response. */
export type WbApiErrorCode = 'bad-request' | 'method-not-found' | 'workspace-not-found' | 'path-escapes-root' | 'list-failed' | 'read-failed' | 'not-a-git-repo' | 'git-unavailable' | 'git-failed' | 'file-not-changed' | 'session-not-found' | 'sessions-full' | 'shell-unavailable' | 'spawn-failed' | 'open-failed';
/** Error envelope of a failed /wb-api response. */
export interface WbApiErrorBody {
    error: {
        code: WbApiErrorCode;
        message: string;
    };
}
//# sourceMappingURL=types.d.ts.map