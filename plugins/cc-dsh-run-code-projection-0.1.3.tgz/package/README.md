# @cc/dsh-run-code-projection

Bound one large tool result: keep a head, a tail and a path to the rest, instead of
re-sending tens of kilobytes on every later step.

A program that prints a report, a JSON page or a whole file hands the model one
`tool/result` of 8–50 KB, and the loop re-sends that result in every subsequent request
until compaction rewrites it. The same holds for `read` on a whole file, `bash` output,
a Hindsight page and the workspace task list; measured 2026-11-18 on session
`session-0b50bf39` (workspace `autolabel_pipeline`): the first two steps of one turn put
190 324 characters (≈43K tokens) into the context, and every later request re-sent them. The evidence is usually in the beginning and the end; the
middle is what makes the step expensive. This plugin replaces such a result with:

```
[tool-result-projection] read 27380 bytes; showing the first 3062 chars and the last 1506 chars, 22772 bytes elided from the middle.
Full text: /home/you/workspace/.dsh/spill/read-call_00_N2I4YMAgAKyOuSQJsXDo0908-1794491656594.txt

<first 3062 characters of the output>

[... 22772 bytes elided from the middle; the full text is the file named above ...]

<last 1506 characters of the output>
```

Nothing is lost: the full text is written **inside the session workspace** before the
banner is returned, and the model reads it back with the ordinary file tools when it needs
the middle. A projection that cannot save at least `minSavingRatio` of the original is not
made at all.

The recovery read is guaranteed, not hoped for: a `read` whose `file_path` lies inside
`spillDir` is never projected, at any size, so the path in the banner always returns the
whole text. `read` also carries its own floor of 64 KiB (`TOOL_MIN_BYTES`), so an ordinary
document reaches the model complete instead of as a banner — measured 2026-11-20: reads of
53 916 and 12 852 bytes arrived with their middle cut, and reading the spill file back was
projected a second time.

Measured on the real fixture in `proof/` (a `run_code` result from this machine's session
log, call `call_00_N2I4YMAgAKyOuSQJsXDo0908`): **27 200 → 4 897 characters (82.0% saved)**;
a 41 208-character result goes to 4 915 characters (88.1%).

## The seam

`tools/post-execute` is the waterfall that may replace a successful tool result's
model-facing `content`; the registry dispatches it at
`@deepseek-ai/dsh-tools/lib/index.js:3600` (`ctx.waterfall(…, 'tools/post-execute', exec,
result, …)`) and applies the `accept`/`block` decision in `postExecute`
(`:3597-3642`). The contract is declared in `dsh-tools/lib/types/index.d.ts:70`. `run_code`
renders exactly one text block (`dsh-tools/lib/index.js:1244`), which is what this policy
replaces.

The listener awaits `next()` first, so any policy that blocks the call, replaces its
`value`, or replaces its `content` stays authoritative; the projection only rewrites the
content that would otherwise reach the model.

## Configuration

| key | default | meaning |
| --- | --- | --- |
| `enabled` | `true` | `false` registers no listener. |
| `tools` | `run_code`, `bash`, `pwsh`, `read`, `web_fetch`, `hindsight_read_page`, `hindsight_search_pages`, `grep`, `glob`, `outline`, `task_list` | tool names whose results may be projected. Compare-and-set tools (`task_get`, `task_update`, `task_close`, `analysis_*`, `delegation_*`) and `skill` are deliberately absent: their full text is either a contract or instructions. |
| `minBytes` | `8192` | shortest result worth projecting (bytes). |
| `headBytes` | `3072` | retained prefix, cut on a UTF-8 boundary. |
| `tailBytes` | `1536` | retained suffix, cut on a UTF-8 boundary. |
| `minSavingRatio` | `0.25` | skip unless this fraction of the original bytes is saved. |
| `maxSpillBytes` | `8388608` | larger results are left untouched (no banner without a file). |
| `spillDir` | `.dsh/spill` | directory under the session workspace for the full text. |
| *(no key)* | `read`: `65536` | `read` has its own floor, exported as `TOOL_MIN_BYTES`; `minBytes` can raise it and cannot lower it. |

Head and tail cuts use `@deepseek-ai/dsh-output-retention`'s `TextRetainer`, so a cut can
never introduce a replacement character or a lone surrogate in the durable log.

## What is never touched

- any tool not in `tools` (and every tool the kit keeps intact: `task_get`, `task_update`, `task_close`, `analysis_*`, `delegation_*`, `skill`);
- a failed result (`isError`), and a decision that blocks or replaces `value`;
- content that is not exactly one text block (images, media, multi-block results);
- a result below `minBytes` (for `read`: below its 64 KiB floor), or one whose projection would not save `minSavingRatio`;
- a `read` of a file inside `spillDir`, at any size: that is the recovery path the banner names;
- an aborted call;
- content that already starts with the banner (idempotent: a second pass creates no file);
- a session with no workspace `cwd` — there would be nowhere legitimate to put the text.

## Failure containment

The spill file is written **before** the banner is returned. If the write or `mkdir`
fails, the result is returned untouched and the failure is logged once per kind: a banner
naming a file that does not exist would be worse than a long result. The listener's own
work is wrapped; a projection failure can never turn a successful tool call into an error.

## Proof

```
node plugins/run-code-projection/proof/proof.mjs
```

It also checks the tool list: `bash` above `minBytes` is projected and the banner names the
tool, an ordinary 12 000-byte document is read whole (under the 64 KiB read floor), a
`read` above that floor is projected, a `task_get` result is untouched, a tool outside the
list is untouched, and a result already carrying the 0.1.x banner is not projected twice.

It drives the plugin's real `tools/post-execute` listener against a real `run_code` result
(fixture extracted read-only from `$DSH_HOME/sessions` with `zstd -dc`), a temporary
directory standing in for the session workspace, and prints before/after characters. It
then feeds the projection back (idempotency), and checks every untouched case: short,
error, image, other tool, aborted, blocked, value-replaced, no workspace, unwritable spill,
insufficient saving. Exit code 0 is the pass.

The recovery is proven on the agent's path: the same listener is run again as a `read` whose
`file_path` is the path printed in the banner — that path as printed, the same file named
relative to the workspace, and a 217 600-byte spill above the read floor — and the result
must come back identical, unbannered and without a second spill file. A `readFileSync` of the spill (what
this proof did up to 0.1.2) cannot see the difference, which is why the defect shipped.

That proof is itself checked against the code it replaced:

```
node plugins/run-code-projection/proof/negative-control.mjs            # pre-fix module at HEAD
node plugins/run-code-projection/proof/negative-control.mjs --ref <pre-fix commit>
```

It copies the module from git into a scratch directory inside the kit, runs the same
`proof.mjs` against it, and requires a non-zero exit with the recovery rows red; a ref that
already carries the fix is refused.
