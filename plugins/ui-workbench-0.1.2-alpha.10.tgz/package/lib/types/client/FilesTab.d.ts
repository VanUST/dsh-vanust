import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from '../locales.ts';
/** Full props of the files tab. */
export interface FilesTabProps {
    /** Registered workspace id for the current session, when one exists. */
    workspaceId: string | undefined;
    /** Absolute path of the current session's workspace, when one exists. */
    workspacePath: string | undefined;
    /** Bound locale translate function. */
    t: TranslateNS<typeof NS>;
}
export declare function FilesTab({ workspaceId, workspacePath, t }: FilesTabProps): import("react").JSX.Element;
//# sourceMappingURL=FilesTab.d.ts.map