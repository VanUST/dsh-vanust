/**
 * Ratchet ratification: asking a human whether a proposed decision becomes law,
 * and turning their answer into the record that makes it so.
 *
 * The problem this module exists for is that a file cannot prove who wrote it. An
 * agent can write `authority: human` into an ADR, and no reader can tell that from
 * a decision a human typed — so "a human approved this" was an assertion the
 * ratchet printed and nobody could check. The answer is not a signature (a key an
 * agent can read is not a secret) but a *channel*: the decision is put to the human
 * as a question, the harness delivers it, and the answer comes back through a path
 * the agent does not author.
 *
 * Four properties make the quiz a consent rather than a formality:
 *
 * 1. **The answer is derived, never interpreted.** Each question offers exactly two
 *    options and the derivation is exact string equality on the selected label. An
 *    answer that matches neither is not "probably a yes": it is unreadable, and the
 *    caller asks again in a different shape. Nothing is minted on a guess.
 * 2. **Consent covers a text.** Every approved record is hashed as it stood when
 *    the question was asked, and the hash is written into the approval. The
 *    compiler honours the approval only while the file still hashes to that value,
 *    so an edit after the fact voids the consent instead of inheriting it.
 * 3. **The evidence is a file, not a claim.** The approval cites a transcript of
 *    the questions and the answers under the sources directory, and the existing
 *    source-hash machinery then detects tampering with it — the same rule every
 *    other decision already faces.
 * 4. **Nothing is written without an approval.** Rejections and unreadable answers
 *    produce no artifact at all, so the corpus cannot drift towards "it was
 *    probably approved".
 *
 * This module imports no harness. The question payload it builds is plain data, and
 * the adapter that owns the harness connection passes it to the user-questions seam
 * and hands the answer back — which is what keeps this logic testable with a
 * literal object instead of a live session.
 */
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { MANIFEST_PATH, UNUSABLE_PROBLEM_CODES, hashSource, normaliseText, problem } from './ratchet-schema.mjs'
import { auditedResolutions, compileLaws, decidableContradictions, readAdrCorpus, readManifest, resolveActiveSet, zonesForRecord } from './ratchet-compiler.mjs'
import { existingAdrIds, nextAdrId, slugFor } from './ratchet-ingest.mjs'
import { writeArtifact, STATE_PATHS } from './ratchet-state.mjs'

/**
 * The channel every ratification the RATCHET'S OWN question seam mints records.
 *
 * One value per surface, because a consent's evidence should name how it was obtained:
 * this one is written when the decision is put to the human as a question through the
 * harness user-questions seam. A surface that puts the same question to a human without
 * that seam records {@link RATIFY_CHANNEL_PANEL} instead — the question, the derivation
 * and the hash binding are identical, and the difference a reader needs is which surface
 * carried it. The value is written into the approval so a future channel is a new value
 * rather than a reinterpretation of this one.
 */
export const RATIFY_CHANNEL = 'user-question'

/**
 * The channel the ADR panel's consent route records.
 *
 * The panel asks the ratchet for its own question, renders it in the decision window and
 * sends back the label the human selected — the same `ratify` operation, without the
 * harness user-questions seam in between. Recording `user-question` for it would put a
 * false statement in a durable record: it would say the harness delivered a question the
 * panel delivered. Both values are in `RATIFICATION_CHANNELS`, and the approval's
 * `Decision` section names the surface the question actually travelled.
 */
export const RATIFY_CHANNEL_PANEL = 'adr-panel'

/** The label that means "put it into force". Exact match, never a prefix. */
export const RATIFY_APPROVE = 'Approve'

/** The label that means "leave it proposed". Exact match, never a prefix. */
export const RATIFY_REJECT = 'Reject'

/**
 * The presentation intent this ratchet's question declares.
 *
 * A client plugin may claim a question from the harness's one composer chain only if it can
 * send every answer that question allows, and the client learns what a question is from
 * `intent.kind`: a request whose intent no presentation claims falls through to the generic
 * flow. Naming the operation is therefore what lets the ADR panel offer this question as two
 * buttons **without** becoming a second consent path — the panel returns the option's own
 * label, and this module derives the decision from it exactly as it does for the chat quiz.
 *
 * Deliberately not `plan-review`: that kind belongs to the plan mode, and the harness renders
 * its own surface for it. A question this ratchet asks is a binary single choice over one
 * record, which is the shape a two-button presentation is allowed to claim.
 *
 * The panel bundle cannot import this constant — it is a standalone browser closure served
 * from its own tarball — so the string is written on both sides and each copy is asserted
 * against the literal. Renaming it in one place alone would silently return the question to
 * the generic flow.
 */
export const RATIFY_INTENT_KIND = 'ratify-decision'

/** Where transcripts of ratification sessions are recorded. */
export const RATIFY_TRANSCRIPT_DIR = 'docs/ratchet/sources'

/**
 * The proposed resolution, if one exists, that would retire the named laws for the named
 * holders on behalf of the record that is blocked.
 *
 * A conflict-free block is only useful if it says how to lift itself. When a resolution has
 * already been drafted — `ratchet_deduplicate` writes one as an ordinary `proposed` record whose
 * `resolves` list names both sides and whose `op: remove` targets the losing law — that draft is
 * the thing to ratify, and naming it is more useful than telling a human to write a second one.
 * The search is deliberately exact: the candidate must be proposed, must name the blocked record
 * and a holder, and must retire one of the named laws (or supersede a holder). A candidate that
 * does not is somebody else's record, and naming it would send the reader to the wrong file.
 *
 * @param record - The not-in-force record whose laws conflict.
 * @param holders - The record ids that put the conflicting laws in force.
 * @param laws - The conflicting law ids.
 * @param records - Every parsed record in the corpus.
 * @returns The candidate's id, or `null` when no proposed resolution matches.
 */
function findDraftedResolution(record, holders, laws, records) {
  const holderSet = new Set(holders)
  const lawSet = new Set(laws)
  for (const candidate of Array.isArray(records) ? records : []) {
    if (candidate === null || typeof candidate !== 'object') continue
    if (candidate.id === record.id || candidate.status !== 'proposed') continue
    const resolves = Array.isArray(candidate.resolves) ? candidate.resolves : []
    if (!resolves.includes(record.id)) continue
    if (![...holderSet].some((holder) => resolves.includes(holder))) continue
    const removes = (candidate.laws ?? []).some((law) => law !== null && typeof law === 'object' && law.op === 'remove' && lawSet.has(law.id))
    const supersedes = Array.isArray(candidate.supersedes) && [...holderSet].some((holder) => candidate.supersedes.includes(holder))
    if (removes || supersedes) return candidate.id
  }
  return null
}

/**
 * The blocked reason for a not-in-force record whose own laws contradict law in force.
 *
 * It answers the three questions a refusal must answer: WHAT contradicts (the record's own
 * removals and re-declarations), WHICH law and WHO holds it in force, and WHAT FIX lifts the
 * block. The fix is stated as the shape a record takes rather than as a command, because the
 * resolution is itself a decision a human ratifies: an ordinary record with
 * `resolves: [holder, this record]` and `op: remove` for the conflicting law, or one that
 * supersedes the holder. When a draft already exists it is named; otherwise the reason points at
 * `ratchet_deduplicate`, which is the tool that drafts one.
 *
 * @param record - The blocked record.
 * @param conflicts - Its conflicts from `decidableContradictions`, each with `lawId`, `op` and
 *   `inForceBy`.
 * @param records - Every parsed record in the corpus, for the draft search.
 * @returns The reason string. Never null; an empty `conflicts` array yields a generic sentence
 *   rather than throwing (callers only call it when there is at least one conflict).
 */
function contradictionBlockReason(record, conflicts, records) {
  const laws = [...new Set((conflicts ?? []).map((conflict) => conflict.lawId))]
  const holders = [...new Set((conflicts ?? []).map((conflict) => conflict.inForceBy).filter((id) => typeof id === 'string' && id.length > 0))]
  const names = laws.map((law) => `"${law}"`).join(', ')
  const holderText = holders.length === 0 ? 'a record the corpus does not name' : holders.map((id) => `ADR ${id}`).join(', ')
  const removes = (conflicts ?? []).filter((conflict) => conflict.op === 'remove')
  const redeclares = (conflicts ?? []).filter((conflict) => conflict.op !== 'remove')
  const what = [
    ...(removes.length === 0 ? [] : [`removes ${removes.map((conflict) => `"${conflict.lawId}"`).join(', ')}`]),
    ...(redeclares.length === 0 ? [] : [`redeclares ${redeclares.map((conflict) => `"${conflict.lawId}"`).join(', ')} with a different statement`]),
  ].join(' and ')
  const draft = findDraftedResolution(record, holders, laws, records)
  const pointer =
    draft === null
      ? '`ratchet_deduplicate` drafts such a resolution when the conflict is a duplicate; otherwise write one by hand and ratify it first'
      : `ADR ${draft} already proposes exactly that resolution, so ratify it first`
  const shape =
    holders.length === 0
      ? `an ordinary record that declares \`resolves: [<the record holding ${laws[0]}>, "${record.id}"]\` and \`laws: [{ op: remove, id: ${laws[0]} }]\`, or one that supersedes that holder`
      : `an ordinary record that declares \`resolves: ["${holders[0]}", "${record.id}"]\` and \`laws: [{ op: remove, id: ${laws[0]} }]\`, or one that supersedes ADR ${holders[0]}`
  return [
    `ADR ${record.id} contradicts law in force and cannot be ratified: it ${what}.`,
    `The conflicting law is ${names}, put in force by ${holderText}.`,
    `A proposed decision may not take away or rewrite what a human already put in force, so the block lifts only when a resolution takes the conflicting law out of force first — ${shape}; ${pointer}.`,
  ].join(' ')
}

/**
 * Lists the decisions that are waiting for a human, and why the others cannot be.
 *
 * A decision is waiting when it is not in force: `proposed` (nobody has decided
 * yet) or excluded (it claims force that the zone does not grant an agent). A
 * decision is NOT offered when ratifying it could not work — an agent record in a
 * `humanOnly` zone, where consent does not transfer authorship — because putting an
 * impossible question to a human wastes the one act this whole mechanism depends
 * on.
 *
 * A HUMAN-authored record that is `proposed` is offered too. Authorship is not the
 * same act as activation: a person can write a decision and leave it proposed — a
 * draft, a decision recorded before the zone that receives it is ready — and the
 * window then showed it as `not in force` with no way to make it one. The only act
 * that puts a record into force through the ratchet is a recorded consent, and a
 * consent must come from a human, so the record is put to the human as the same
 * question every other not-in-force record gets. Approving it writes the human's own
 * approval and its transcript; nothing about this path is an agent mint. The record
 * keeps its own author authority, and the compiler already activates a human-authored
 * record from the consent alone (`resolveActiveSet`: `selfAuthorised || effectiveConsent`),
 * so no zone rule is relaxed. A human-authored record that is terminal (rejected,
 * withdrawn, superseded) is still not offered, because a "yes" must not put a
 * retired decision back into law.
 *
 * A record is ALSO blocked, not offered, when its own laws contradict law in force:
 * `decidableContradictions` reports a record that removes or rewrites an in-force law without
 * being a resolution the compiler accepted, and `contradictionBlockReason` states the resolution
 * that would take the conflicting law out of force. Ratifying such a record would take away what
 * a human already put in force, which is exactly what a ratification cannot do — so the queue
 * refuses it and names the fix instead of putting an impossible question to the human.
 *
 * ONE shape is offered rather than refused, and it is the one the lifecycle itself needs: an
 * AMENDMENT, a proposed record that removes law in force AND restates the decision under a new
 * law id. The consent a removal requires is exactly the question the queue would put, so the
 * record is offered; the write guard's law is unchanged and still treats the not-in-force
 * removal as a contradiction until the human puts it into force. Without this, no amendment
 * could ever be ratified — which is how ADR 0043 and ADR 0045 entered force before the queue's
 * contradiction block existed.
 *
 * @param root - Absolute project root.
 * @returns `{ ok, config, pending, blocked, problems }`. `pending` entries carry
 *   the record's full text and its current content hash, so a caller can show a
 *   human exactly what a "yes" would cover. `blocked` entries carry the same
 *   fields plus `reason`. A project with no usable manifest returns `ok: false`
 *   with the manifest's own problems rather than an empty queue.
 */
export function ratificationQueue(root) {
  const manifest = readManifest(root)
  const config = manifest.config
  if (config === null) {
    return { ok: false, config: null, pending: [], blocked: [], problems: manifest.problems }
  }
  if (config.enabled !== true) {
    return {
      ok: false,
      config,
      pending: [],
      blocked: [],
      problems: [
        problem(
          'RATCHET_DISABLED',
          `${config.manifestHash === null ? 'the manifest' : 'the project manifest'} does not declare ratchet.enabled, so no decision is enforced here and there is nothing to ratify`,
        ),
      ],
    }
  }

  const corpus = readAdrCorpus(root, config)
  const resolved = resolveActiveSet(corpus.records, config)
  // A corpus the ratchet cannot read is not a queue with nothing in it. Reporting
  // `ok` for one made `ratchet pending` print OK and exit 0 on a tree whose decisions
  // directory does not exist, where every other command exits 2.
  const unusable = (corpus.problems ?? []).some((entry) => UNUSABLE_PROBLEM_CODES.includes(entry.code))
  const excluded = new Set(resolved.excluded)
  const pending = []
  const blocked = []

  // The one fact the queue and the write guard must agree on: what is law, and which records the
  // compiler accepted as a resolution. A proposed record whose own laws remove or rewrite a law
  // in force cannot be ratified until a resolution takes that law out of force, and it is blocked
  // with the fix rather than put to a human (`decidableContradictions`, `auditedResolutions`).
  const inForce = compileLaws(resolved.active, config)
  const resolutions = auditedResolutions(corpus.records, {
    active: resolved.active,
    removedByDecision: inForce.removedByDecision,
    problems: corpus.problems,
  })

  for (const record of [...resolved.proposed, ...resolved.excluded]) {
    // Every not-in-force record that is not terminal is offered, whatever its author. A
    // human-authored record is not queued because an agent may activate it — an agent never
    // may — but because the human's own recorded consent is the one act that does. Refusing
    // to offer it left a `status: proposed`, `authority: human` record permanently "not in
    // force" with no affordance in the window, which is the dead end this branch removes.
    // The zone checks below are what keep the offer honest: an agent record in a `humanOnly`
    // zone is still blocked, because consent cannot transfer authorship.
    const zones = zonesForRecord(record, config)
    const humanOnly = zones.filter((zone) => zone.agentAuthority === 'humanOnly')
    let text = null
    let readError = null
    try {
      text = normaliseText(readFileSync(join(root, record.path), 'utf8'))
    } catch (error) {
      readError = String(error)
    }

    const entry = {
      id: record.id,
      title: record.title,
      path: record.path,
      status: record.status,
      authority: record.authority,
      zones: zones.map((zone) => zone.id),
      zonePolicies: zones.map((zone) => zone.agentAuthority),
      contentHash: record.contentHash,
      laws: (record.laws ?? []).map((law) => ({
        id: law.id,
        statement: typeof law.statement === 'string' ? law.statement : null,
        op: law.op ?? 'upsert',
        checks: Array.isArray(law.checks) ? law.checks.length : 0,
      })),
      excluded: excluded.has(record),
      text,
    }

    if (record.authority === 'agent' && humanOnly.length > 0) {
      blocked.push({
        ...entry,
        reason: `zone "${humanOnly[0].id}" declares agentAuthority humanOnly, and a ratified agent record is still agent-authored: this decision has to be replaced by a human-authored record rather than approved`,
      })
      continue
    }
    // A record naming a zone the manifest does not declare cannot become law however
    // the human answers: the law it declares would be reported LAW_ZONE_MISSING the
    // moment it entered force. Offering it as "waiting for you" produced a consent
    // that achieved nothing and a report that got worse, with nothing telling the
    // human why.
    const undeclared = zones.filter((zone) => zone.missing === true)
    if (undeclared.length > 0) {
      blocked.push({
        ...entry,
        reason: `the record names zone "${undeclared[0].id}", which ${MANIFEST_PATH} does not declare, so nothing it declares could enter force: fix the zone list in the record or add the zone to the manifest first`,
      })
      continue
    }
    if (text === null) {
      blocked.push({ ...entry, reason: `the record file could not be read: ${readError}` })
      continue
    }
    const conflicts = decidableContradictions(record, inForce.bundle.laws, { resolutions })
    if (conflicts.length > 0) {
      // An AMENDMENT — a proposed record that removes law in force AND restates the decision
      // under a new law id — is EXACTLY a decision a human must be asked about, not one the
      // queue refuses. Refusing it made every amendment unratifiable, which is not the shape the
      // lifecycle the corpus already holds (ADR 0043 removed six laws and restated them, ADR 0045
      // removed one) could have been ratified under. The consent the removal requires is this
      // question, so the record is offered. The write guard is deliberately NOT changed: its own
      // law (`…a-contradiction-with-law-in-force-stops-the-work`) still treats the not-in-force
      // removal as a contradiction until the human puts it into force.
      const inForceIds = new Set((inForce.bundle?.laws ?? []).map((law) => law.id))
      const isAmendment =
        conflicts.some((conflict) => conflict.op === 'remove') &&
        (record.laws ?? []).some(
          (law) => law !== null && typeof law === 'object' && law.op !== 'remove' && typeof law.id === 'string' && !inForceIds.has(law.id),
        )
      if (!isAmendment) {
        blocked.push({ ...entry, reason: contradictionBlockReason(record, conflicts, corpus.records) })
        continue
      }
    }
    pending.push(entry)
  }

  return { ok: !unusable, config, pending, blocked, problems: corpus.problems }
}

/**
 * Builds the quiz for one set of decisions.
 *
 * Attempt 1 puts one question per decision, offering `Approve` and `Reject`. A
 * second attempt exists because an answer can arrive unreadable, and asking the
 * same question again is how a human and a machine talk past each other: the
 * repeated question carries the previous answer, and its labels name the decision
 * (`Approve ADR 0001`) so a label that does not belong to the question is visible
 * rather than silently mapped.
 *
 * WHERE THE QUESTION IS SHOWN is part of the question, not a property of the caller
 * that a presentation could look up: `present` decides whether the batch declares the
 * `ratify-decision` presentation intent. `'panel'` declares it, and a client that
 * claims that intent renders the question itself instead of the harness's own card.
 * `'chat'` declares nothing, so the harness renders the question in the Conversation —
 * and that is the whole difference between an agent's proposal, which is put to a human
 * in the decision viewer it belongs to, and a grilling session, where the agent is
 * talking to the human anyway and the question must block that conversation until it is
 * answered. A question that declared the intent and was shown in neither place would be
 * unanswerable; making the choice explicit is what keeps a presentation from silently
 * swallowing a question no surface then offers.
 *
 * @param entries - Queue entries to ask about; an empty list yields a quiz with no
 *   questions, which callers must treat as "nothing to ask".
 * @param options - `{ attempt, previous, present }`. `attempt` is 1 or 2; for attempt
 *   2, `previous` carries the unreadable results from attempt 1, whose `reason` and
 *   `raw` are shown. `present` is `'panel'` (the default) or `'chat'`; an unrecognised
 *   value is treated as `'chat'`, because a presentation that is not explicitly the
 *   panel's is one the panel must not claim on the ratchet's behalf.
 * @returns `{ attempt, questions, roles, frozen }`. `questions` is exactly the
 *   payload the harness user-questions seam accepts — plain data, no private
 *   fields, because anything else would have to survive the wire. `roles` maps each
 *   question id to `{ adrId, approveLabel, rejectLabel }`, which is what makes the
 *   derivation a lookup instead of a guess. `frozen` is the same records as they
 *   stood when the question was built: `{ id, path, contentHash }`, kept so a
 *   consent can be bound to the text the human was SHOWN rather than to whatever
 *   the file says when the answer arrives.
 */
export function buildQuiz(entries, { attempt = 1, previous = [], present = 'panel' } = {}) {
  const forPanel = present === 'panel'
  const questions = []
  const roles = {}
  const frozen = []
  for (const entry of entries ?? []) {
    const prior = previous.find((item) => item.id === entry.id) ?? null
    const approveLabel = attempt === 1 ? RATIFY_APPROVE : `${RATIFY_APPROVE} ADR ${entry.id}`
    const rejectLabel = attempt === 1 ? RATIFY_REJECT : `${RATIFY_REJECT} ADR ${entry.id}`
    const questionId = attempt === 1 ? `ratify-${entry.id}` : `ratify-again-${entry.id}`
    const lawCount = entry.laws.filter((law) => law.op !== 'remove').length
    questions.push({
      id: questionId,
      header: attempt === 1 ? `Ratify ADR ${entry.id}` : `Answer not readable — ADR ${entry.id}`,
      // The presentation intent, naming the operation and the label that means "yes". Two
      // buttons can express every answer this question allows — one approve label, one
      // other option, single choice — which is the condition the harness puts on a
      // presentation claiming a question, and the condition the ADR panel must re-check
      // before it claims one. It is attached ONLY for the panel: the harness's own card is
      // the presentation that offers a free-text answer, and a grilling session needs that
      // card rather than a surface the human has to leave the conversation to find.
      // `targetId` names the record the question is about, so a presentation can settle the
      // question for the record the human actually clicked. Without it a client would have to
      // parse the question id to learn the target, which is the ratchet's private naming and
      // not a contract. A presentation that cannot tell which record is being asked about
      // must not answer on the human's behalf.
      ...(forPanel
        ? { intent: { kind: RATIFY_INTENT_KIND, approve: approveLabel, targetId: entry.id } }
        : {}),
      question:
        attempt === 1
          ? `Put "${entry.title ?? entry.id}" into force as law?`
          : `Your previous answer about ADR ${entry.id} could not be read as approval or rejection` +
            `${prior === null || prior.reason === undefined ? '' : ` (${prior.reason})`}. ` +
            `Put "${entry.title ?? entry.id}" into force as law? Pick one of the two options below.`,
      // The detail is the record's own file text: the human is shown exactly the
      // bytes the content hash covers. A summary would be kinder to read and would
      // make the hash cover something nobody saw.
      detail: entry.text,
      options: [
        {
          label: approveLabel,
          description:
            lawCount === 0
              ? 'This decision declares no law; approving it changes nothing the verifier checks.'
              : `Put ${lawCount} law${lawCount === 1 ? '' : 's'} into force: ${entry.laws
                  .filter((law) => law.op !== 'remove')
                  .map((law) => law.id)
                  .join(', ')}`,
        },
        {
          label: rejectLabel,
          description: 'Leave the decision proposed. Nothing is written and nothing enters force.',
        },
      ],
    })
    roles[questionId] = { adrId: entry.id, approveLabel, rejectLabel }
    frozen.push({ id: entry.id, path: entry.path ?? null, contentHash: entry.contentHash ?? null })
  }
  return { attempt, questions, roles, frozen }
}

/**
 * Finds what one question offered, as it stood when the question was built.
 *
 * @param quiz - Result of {@link buildQuiz}.
 * @param adrId - The record id the answer is about.
 * @returns `{ id, path, contentHash }`, or `null` when the quiz never offered it.
 */
export function offeredBy(quiz, adrId) {
  return (quiz?.frozen ?? []).find((entry) => entry.id === adrId) ?? null
}

/**
 * Derives one decision per question from a human's answer.
 *
 * The whole point is that nothing here is a judgement call. A selected label equal
 * to the question's approve label is an approval, equal to its reject label is a
 * rejection, and everything else — no answer, no selection, several selections, a
 * label from another question, free text with no choice — is unreadable, reported
 * with what actually arrived. A caller may re-ask; it may not infer.
 *
 * @param quiz - Result of {@link buildQuiz}.
 * @param answer - The harness answer: `{ answers: [{ id, selected, custom? }] }`,
 *   or `null`/`undefined` when the human closed the question without answering.
 * @returns `{ decisions, unreadable, approved, rejected }`. `decisions` holds one
 *   entry per question in quiz order: `{ adrId, questionId, decision, selected,
 *   custom }` with `decision` one of `approved` / `rejected` / `unreadable`.
 *   `unreadable` carries `{ id, questionId, reason, raw }` for the re-ask.
 */
export function deriveDecisions(quiz, answer) {
  const answers = Array.isArray(answer?.answers) ? answer.answers : []
  const decisions = []
  const unreadable = []

  for (const [questionId, role] of Object.entries(quiz?.roles ?? {})) {
    const item = answers.find((entry) => entry !== null && typeof entry === 'object' && entry.id === questionId)
    const selected = Array.isArray(item?.selected)
      ? item.selected.filter((label) => typeof label === 'string')
      : []
    const custom = typeof item?.custom === 'string' && item.custom.trim().length > 0 ? item.custom.trim() : null

    const record = (decision, reason) => {
      decisions.push({
        adrId: role.adrId,
        questionId,
        decision,
        selected,
        custom,
      })
      if (decision === 'unreadable') {
        unreadable.push({ id: role.adrId, questionId, reason, raw: { selected, custom } })
      }
    }

    if (item === undefined) {
      record('unreadable', 'no answer was recorded for this question')
      continue
    }
    if (selected.length === 0) {
      record(
        'unreadable',
        custom === null
          ? 'the answer selected none of the offered options'
          : `the answer was free text rather than one of the offered options: ${JSON.stringify(custom)}`,
      )
      continue
    }
    if (selected.length > 1) {
      record(
        'unreadable',
        `the answer selected ${selected.length} options (${selected.map((label) => JSON.stringify(label)).join(', ')}), so it names no single decision`,
      )
      continue
    }
    if (selected[0] === role.approveLabel) {
      record('approved', null)
      continue
    }
    if (selected[0] === role.rejectLabel) {
      record('rejected', null)
      continue
    }
    record(
      'unreadable',
      `the answer selected ${JSON.stringify(selected[0])}, which is neither of this question's options (${JSON.stringify(role.approveLabel)} / ${JSON.stringify(role.rejectLabel)})`,
    )
  }

  return {
    decisions,
    unreadable,
    approved: decisions.filter((entry) => entry.decision === 'approved').map((entry) => entry.adrId),
    rejected: decisions.filter((entry) => entry.decision === 'rejected').map((entry) => entry.adrId),
  }
}

/**
 * Renders the transcript of one ratification session.
 *
 * This is the raw source the approval ADR cites, so it holds the questions that
 * were asked, the options that were offered, and the answer that arrived, with no
 * interpretation added. Two reasons it is a file rather than a field: the existing
 * source-hash machinery then covers it like any other reasoning, and a reader can
 * check the derivation by hand — which is the only way "the machine read my answer
 * correctly" stops being a matter of trust.
 *
 * @param options - `{ project, at, askedBy, channel, quiz, answer, decisions,
 *   entries }`.
 * @returns Markdown text. Always non-empty, including when nothing was answered:
 *   a session that produced no consent is still a fact worth recording.
 */
export function renderTranscript({ project, at, askedBy, channel, quiz, answer, decisions, entries }) {
  const byId = new Map((entries ?? []).map((entry) => [entry.id, entry]))
  const lines = [
    `# Ratification transcript — ${project ?? '(unnamed project)'}`,
    '',
    `- at: ${at}`,
    `- asked by: ${askedBy}`,
    `- channel: ${channel}`,
    `- questions asked: ${quiz.questions.length}`,
    `- answered: ${(answer?.answers ?? []).length}`,
    '',
  ]

  for (const question of quiz.questions) {
    const role = quiz.roles[question.id]
    const decision = decisions.find((entry) => entry.questionId === question.id) ?? null
    const entry = byId.get(role.adrId) ?? null
    const answerItem = (answer?.answers ?? []).find((item) => item?.id === question.id) ?? null
    lines.push(
      `## ${question.header}`,
      '',
      question.question,
      '',
      `- record: ${entry?.path ?? '(unknown)'}`,
      `- content hash offered: ${entry?.contentHash ?? '(unknown)'}`,
      `- options: ${question.options.map((option) => option.label).join(' | ')}`,
      `- selected: ${answerItem === null || answerItem.selected === undefined ? '(nothing)' : JSON.stringify(answerItem.selected)}`,
      ...(typeof answerItem?.custom === 'string' && answerItem.custom.length > 0
        ? [`- free text: ${JSON.stringify(answerItem.custom)}`]
        : []),
      `- derived: ${decision === null ? '(no derivation)' : decision.decision}`,
      '',
    )
  }

  lines.push(
    'The derivation above is exact: a selected label equal to the question\'s approve',
    'label is an approval, equal to its reject label is a rejection, and anything else',
    'is unreadable and mints nothing.',
    '',
    'The record text itself is not copied here. It is the file named above, committed',
    'beside this transcript, and the recorded hash is what makes an edit after the fact',
    'visible — while the committed revision is where the exact text the human read can',
    'still be found.',
    '',
  )
  return `${lines.join('\n')}\n`
}

/**
 * Renders the approval ADR a ratification writes.
 *
 * The artifact is an ordinary ADR of `type: approval`, so it travels the same path
 * every other decision does: it compiles, it is reviewed in a diff, and it is the
 * thing the compiler reads to decide what is in force. What it adds is the
 * `ratification` block — the channel, the time, who asked, and one content hash per
 * approved record — which is what turns "an approval exists" into "an approval of
 * this text exists".
 *
 * @param options - `{ id, at, askedBy, channel, approved, transcriptPath,
 *   transcriptHash, project, decisionsDir }`. `approved` is the queue entries being
 *   put into force; an empty list is refused by the caller, not here. `channel` is one
 *   of `RATIFICATION_CHANNELS` — `user-question` for a question the harness delivered,
 *   `adr-panel` for one the ADR panel's decision window rendered — and it selects both
 *   the recorded value and the sentence that names the surface.
 * @returns `{ filename, path, text, title }`.
 */
export function renderApprovalAdr({
  id,
  at,
  askedBy,
  channel = RATIFY_CHANNEL,
  approved,
  transcriptPath,
  transcriptHash,
  project = null,
  decisionsDir = 'docs/adrs',
}) {
  const ids = approved.map((entry) => entry.id)
  const title = `Ratify ${ids.length === 1 ? `ADR ${ids[0]}` : `ADRs ${ids.join(', ')}`}`
  const filename = `${id}-${slugFor(title)}.adr.md`
  const plural = ids.length === 1 ? false : true
  const lawLines = approved.flatMap((entry) =>
    entry.laws.filter((law) => law.op !== 'remove').map((law) => `- \`${law.id}\` — ${law.statement ?? '(no statement)'} (${entry.path})`),
  )
  // The context is generated from each record's own status and zone policies rather
  // than asserted about them: a decision can be waiting because the zone refuses an
  // agent's own activation, or simply because nobody has decided yet, and a record
  // that says the wrong one of those is a record a reader has to re-derive.
  const contextLines = approved.flatMap((entry) => [
    `- ADR ${entry.id} — ${entry.title ?? '(no title)'} (${entry.path})`,
    `  - status: ${entry.status}; author authority: ${entry.authority}`,
    `  - zones: ${entry.zones.length === 0 ? '(unzoned)' : entry.zones.map((zone, index) => `${zone} (${entry.zonePolicies[index] ?? 'unknown'})`).join(', ')}`,
  ])

  const text = [
    '---',
    `id: "${id}"`,
    `title: ${title}`,
    'type: approval',
    // Active, because an approval that is itself proposed would put nothing into
    // force. This is the one record type whose force does not come from being
    // approved by something else; it is the consent artifact.
    'status: active',
    'author:',
    '  authority: human',
    '  name: human',
    `created: ${at}`,
    'source:',
    '  kind: file',
    `  path: ${transcriptPath}`,
    `  hash: ${transcriptHash}`,
    'zones: []',
    'laws: []',
    'supersedes: []',
    'approves:',
    ...ids.map((entry) => `  - "${entry}"`),
    'ratification:',
    `  channel: ${channel}`,
    `  at: '${at}'`,
    `  askedBy: ${askedBy}`,
    '  targets:',
    ...approved.flatMap((entry) => [
      `    - id: "${entry.id}"`,
      `      contentHash: ${entry.contentHash}`,
    ]),
    '---',
    '',
    '## Context',
    '',
    ...contextLines,
    '',
    `${plural ? 'These records are' : 'This record is'} not in force. A decision record is not a decision until somebody with the`,
    'authority makes it one, and the ratchet will not infer that from a status field an',
    'agent can write: in a `proposeOnly` zone the author cannot activate its own',
    'decision, and in any zone an agent that declares itself active is making the claim',
    'the gate exists to check.',
    '',
    '## Decision',
    '',
    // The sentence names the surface that actually carried the question, because the
    // `channel` value above is read by a reviewer who wants to know how a consent was
    // obtained — and the two implemented channels are not the same act, even though the
    // question, the derivation and the hash binding are identical.
    channel === RATIFY_CHANNEL_PANEL
      ? `A human was asked, in the ADR panel's decision window, whether ${plural ? 'these records' : 'this record'} should enter force,`
      : `A human was asked, through the harness user-questions channel, whether ${plural ? 'these records' : 'this record'} should enter force,`,
    `and selected **${RATIFY_APPROVE}** for ${plural ? 'each' : 'it'}. ${ids.map((entry) => `ADR ${entry}`).join(' and ')} ${plural ? 'are' : 'is'} ratified at the content hashes recorded in`,
    'the frontmatter above and now contributes law.',
    '',
    ...(lawLines.length === 0
      ? [`The ratified ${plural ? 'records declare' : 'record declares'} no law, so nothing the verifier checks changes.`, '']
      : [`The law${lawLines.length === 1 ? '' : 's'} brought into force:`, '', ...lawLines, '']),
    '## Reasoning',
    '',
    'Consent is recorded rather than asserted. The question showed the human the exact',
    'text of each record, the answer was taken as a selected option with no',
    'interpretation, and the transcript of both is the source cited above — so the',
    `derivation can be re-read at ${transcriptPath} instead of trusted.`,
    '',
    `Each approved record is bound to the hash it had when the question was asked, so this approval covers that text and`,
    'not a later revision of it. An approval that named only a title would keep',
    'approving whatever the file said next, which is how a decision gets substituted',
    'past the person who read it. The text itself is not copied here: it is the record,',
    'committed beside this approval, and the hash is what makes a substitution visible',
    'rather than silent.',
    '',
    ...(project === null ? [] : [`Project: ${project}`, '']),
    '## Consequences',
    '',
    '- Editing any ratified record voids this approval: the compiler reports `RATIFICATION_STALE` and the law leaves force until it is ratified again.',
    '- The law set changed, so the spec bundle must be recompiled and the code re-verified before anything is called checked.',
    '- This approval confers force only. The ratified records keep their own author authority, so a ratified agent record still cannot govern a zone reserved to humans.',
    '',
  ].join('\n')

  return { filename, path: `${String(decisionsDir).replace(/\/+$/, '')}/${filename}`, text, title }
}

/**
 * Writes a ratification's two artifacts, refusing to overwrite anything.
 *
 * The transcript is written first: the approval cites it and records its hash, so
 * writing the approval first would create a record whose evidence does not exist
 * yet. Both writes go through the shared atomic writer, because a half-written
 * approval is an approval of unknown text.
 *
 * @param root - Absolute project root.
 * @param artifacts - `{ transcriptPath, transcriptText, approvalPath,
 *   approvalText }`.
 * @returns `{ ok, written, problems }`; `ok` is false when either target already
 *   exists, because a ratification that silently kept an older file would leave the
 *   caller believing a consent was recorded that was not.
 */
export function writeRatification(root, { transcriptPath, transcriptText, approvalPath, approvalText }) {
  const targets = [transcriptPath, approvalPath]
  const existing = []
  for (const path of targets) {
    try {
      readFileSync(join(root, path))
      existing.push(path)
    } catch {
      // Absent is the expected case: a ratification never rewrites history.
    }
  }
  if (existing.length > 0) {
    return {
      ok: false,
      written: [],
      problems: [
        problem(
          'ADR_ID_DUPLICATE',
          `refusing to write a ratification over ${existing.join(', ')}; a ratification records a consent that already happened, and overwriting one would erase the evidence of it`,
          null,
          { existing },
        ),
      ],
    }
  }

  const written = []
  try {
    const transcript = writeArtifact(root, transcriptPath, transcriptText)
    const approval = writeArtifact(root, approvalPath, approvalText)
    written.push(transcript.path, approval.path)
  } catch (error) {
    return {
      ok: false,
      written,
      problems: [
        problem(
          'ADR_UNREADABLE',
          `the ratification could not be written: ${String(error)}; nothing is in force through it, and any file already written is named in "written" so the caller can remove it rather than guess`,
          null,
          { written },
        ),
      ],
    }
  }
  return { ok: true, written, problems: [] }
}

/**
 * Chooses the path for a ratification transcript.
 *
 * Dated because the same decision can legitimately be ratified more than once — an
 * approved record that is then edited loses its consent and has to be ratified
 * again — and a second ratification that reused the first transcript's path would be
 * refused by the write, turning a normal event into a hard failure. The counter
 * covers a second ratification of the same decisions on the same day, which is
 * exactly what re-ratifying an edited record looks like.
 *
 * @param root - Absolute project root.
 * @param options - `{ sourcesDir, at, ids }`.
 * @returns A repository-relative path with forward slashes and no existing file.
 */
export function transcriptPathFor(root, { sourcesDir, at, ids }) {
  const day = String(at).slice(0, 10).replace(/[^0-9-]/g, '') || 'undated'
  const directory = String(sourcesDir ?? RATIFY_TRANSCRIPT_DIR).replace(/\/+$/, '')
  const base = `${directory}/${day}-ratification-${ids.join('-')}`
  let path = `${base}.md`
  let counter = 2
  while (existsSync(join(root, path))) {
    path = `${base}-${counter}.md`
    counter += 1
  }
  return path
}

/**
 * Allocates the id for a new approval ADR.
 *
 * @param root - Absolute project root.
 * @param decisionsDir - Manifest-declared decisions directory.
 * @returns `{ id }`; the next free four-digit id, so an approval never collides
 *   with a decision that already exists.
 */
export function nextApprovalId(root, decisionsDir) {
  const existing = existingAdrIds(root, decisionsDir)
  return { id: nextAdrId(existing.ids), existing: existing.ids }
}

/** Re-exported so a caller needs one import for the ratification path. */
export { STATE_PATHS, hashSource }
