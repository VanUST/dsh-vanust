/**
 * Deployment model-cost gate for the DeepSeek official route.
 *
 * Watches the `llm/stream` waterfall (the single chokepoint every model
 * dispatch passes: root turns, subagents, compaction, session titles) and
 * vetoes requests whose exact `model` is not on the deployment allowlist.
 * The veto throws *before* the waterfall's base `next()` runs, so the
 * adapter is never invoked and nothing is dispatched or billed.
 *
 * The gate is opt-in (`enabled: true`) so the plugin stays neutral for
 * adopters that do not want it; the dsh-kit deployment profile enables it
 * with the flash-only allowlist (cost policy, ~3x deepseek-v4-pro premium).
 *
 * @module @deepseek-ai/dsh-host-web-workbench/flash-only-gate
 */
import type { Context } from '@deepseek-ai/cordis';
/** Default allowlist: the flash tier of the deepseek-official route. */
export declare const FLASH_ONLY_DEFAULT_MODELS: readonly string[];
/** Stable failure code carried by every vetoed request. */
export declare const FLASH_ONLY_ERROR_CODE = "MODEL_NOT_ALLOWED";
/** Deployment configuration of the gate. */
export interface FlashOnlyGateConfig {
    /** Whether the gate is active. @default false */
    enabled?: boolean;
    /** Exact model ids allowed to reach the adapter. @default FLASH_ONLY_DEFAULT_MODELS */
    allowedModels?: string[];
}
/**
 * Install the gate on one context.
 * @param ctx - Cordis context whose `llm/stream` dispatches are gated.
 * @param config - deployment configuration.
 * @returns a disposer, or `undefined` when the gate is disabled.
 * @throws when enabled with an empty effective allowlist (misconfiguration).
 */
export declare function installFlashOnlyGate(ctx: Context, config: FlashOnlyGateConfig): (() => void) | undefined;
//# sourceMappingURL=flash-only-gate.d.ts.map