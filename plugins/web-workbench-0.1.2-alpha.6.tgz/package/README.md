---
description: "Host side of the web workbench plugin pair: workspace file listing/reading, git review and line-based terminal sessions over plain /wb-api HTTP routes on the stock webserver."
kind: "package-reference"
---

# @deepseek-ai/dsh-host-web-workbench

## Summary

`dsh-host-web-workbench` is the host half of the web workbench plugin pair
(its browser half is `@deepseek-ai/dsh-client-ui-workbench` plus
`@deepseek-ai/dsh-client-ui-terminal`). It gives the web GUI's workbench and
terminal panels a real host surface without any new RPC machinery: one
`/wb-api` prefix route on the stock webserver (`ctx.webServer.register`)
serves JSON endpoints for workspace file listing/reading, git changes/diffs,
and system file-manager integration, plus a WebSocket upgrade route
(`ctx.webServer.registerUpgrade`) for terminal sessions.

The design rule is that every file request resolves through the workspace
registry (`ctx.workspaceRegistry.get(id)`), so the browser names a registered
workspace — never a filesystem path — and file paths are additionally guarded
against traversal. Terminal sessions allocate a real kernel PTY through
`node-pty` (the same PTY substrate VS Code, alacritty and kitty use) bridged
to the browser over the WebSocket — full-screen interactive programs work.
Browser assets (the vendored xterm.js + its stylesheet, MIT) are served from
`/wb-api/static/`.

## Endpoints (prefix `/wb-api`)

| Method + path | Parameters | Response |
|---|---|---|
| `GET /workspace/list` | `workspaceId` | `{items, truncated}` — recursive walk, dirs first, `.git` skipped |
| `GET /workspace/read` | `workspaceId`, `path` | `{content, truncated, path}` — bounded UTF-8 read |
| `GET /workspace/changes` | `workspaceId` | `{items}` — `git status --porcelain` folded |
| `GET /workspace/diff` | `workspaceId`, `path` | `{diff, truncated}` — unified diff; untracked → all-additions |
| `GET /terminal/list` | — | `{sessions}` (live PTY sessions) |
| `POST /terminal/close` | body `{sessionId}` | `{closed: true}` |
| `POST /system/open` | body `{workspaceId, path?}` | `{opened: true}` — launches the system file manager (xdg-open) on the path |
| `GET /system/capabilities` | — | `{tuiFileManager, openCommand}` |
| `GET /health` | — | `{ok: true}` |
| `GET /static/xterm.js` / `xterm.css` | — | vendored xterm assets (allowlisted) |
| `WS /terminal/ws` | query `cwd`, `cols`, `rows`, `cmd?` | one PTY session per socket; see below |

Failures return a JSON envelope `{error: {code, message}}` with a stable
machine-readable code (`workspace-not-found`, `path-escapes-root`,
`not-a-git-repo`, `git-failed`, `session-not-found`, …) and a matching HTTP
status (400/404/500).

## Terminal WebSocket protocol

`ws://host/wb-api/terminal/ws?cwd=<dir>&cols=100&rows=30&cmd=<program>` — the
host spawns a real PTY (shell, or `cmd` when given, e.g. a TUI file manager)
and owns it for the socket's lifetime.

- Client → server: `{type:'input',data}`, `{type:'resize',cols,rows}`, `{type:'close'}`.
- Server → client: `{type:'ready',sessionId,program}`, `{type:'output',data}`,
  `{type:'exit',exitCode}`, `{type:'error',code,message}`.
- On socket close the PTY is killed; on PTY exit the socket is closed.

## Configuration

| Key | Default | Meaning |
|---|---|---|
| `gitPath` | `git` | git executable |
| `diffMaxBytes` | 512 KiB | one diff cap (larger → truncated + killed) |
| `readMaxBytes` | 256 KiB | one file read cap |
| `listMaxEntries` | 2000 | one listing cap |
| `timeoutMs` | 10 000 | git invocation timeout |
| `shell` / `args` | `$SHELL` / `[]` | terminal shell and fixed args |
| `cwd` | host cwd | default terminal working directory |
| `ptyName` | `xterm-256color` | PTY type (TERM inside sessions) |
| `maxSessions` | 4 | concurrent terminal sessions |
| `openCommand` | `xdg-open` | system file-manager launcher |
| `tuiFileManager` | auto (yazi/ranger/mc probe) | TUI file manager offered by the Files tab; unset probes PATH |

## Security posture

- Loopback-bound webserver only; no CORS headers are emitted (same-origin SPA).
- Workspace ids are resolved host-side through the registry; a client cannot
  name an arbitrary directory.
- File paths are resolved against the workspace root and rejected when they
  escape it; reads are bounded; git args are fixed arrays (no shell
  interpolation).
- Terminal sessions run under the host user inside a real PTY
  (`ptyName` TERM); sessions are killed on plugin unload.
- `node-pty` and `ws` resolve from the installation closure (the harness's
  terminal family and API gateway already depend on them) — no new native
  builds.
- Static assets are allowlisted by name (`xterm.js`, `xterm.css`) and cached
  in memory.

## Model Experience

None: the bridge serves the human-facing panels and never reaches a model
request.

#### KV Cache effect

None.
