/**
 * `git status --porcelain=v1` parsing: fold the index/worktree letter pair
 * into the closed review status vocabulary and split NUL-delimited records,
 * including the two-field rename/copy form.
 * @module @deepseek-ai/dsh-host-web-workbench/src/porcelain
 */
import type { ChangedFileView, WorkspaceReviewStatus } from './types.ts';
/**
 * Fold one porcelain letter pair into the closed review status vocabulary.
 * @param x - index-column letter.
 * @param y - worktree-column letter.
 * @returns the folded status and staged bit.
 */
export declare function statusFor(x: string, y: string): {
    status: WorkspaceReviewStatus;
    staged: boolean;
};
/**
 * Parse `git status --porcelain=v1 -z` output. Rename and copy rows carry a
 * second NUL-delimited field naming the source path.
 * @param stdout - NUL-delimited porcelain records.
 * @returns ordered changed-file views.
 */
export declare function parseStatus(stdout: Buffer): ChangedFileView[];
/** Re-export the status union under its porcelain-module name. */
export type { WorkspaceReviewStatus };
//# sourceMappingURL=porcelain.d.ts.map