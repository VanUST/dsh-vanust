# @cc/dsh-taskboard

The task-centered dashboard that replaces the subagent catalog as the place work
is tracked.

## What it stores

One JSON ledger per session workspace, `.dsh/taskboard.json`:

- `id`, `revision`, `title`, `objective`, `chatId`
- `scope[]`, `nonScope[]`, `acceptance[{text,done}]`
- `status` — proposed, ready, active, paused, review, done, blocked, cancelled
- `priority`, `owner`, `parentId`, `parentSessionId`, `dependsOn[]`, `childSessionIds[]`,
  `children[{sessionId,label,role,status,startedAt,endedAt,stopReason}]`
- `role` on a task; `agents[{role,label,sessionId,preset,status,taskCount,lastTaskId}]` for the persistent specialist roster
- `result { summary, evidence[], artifacts[], decisions[], risks[] }`
- `timeline[{at, kind, actor, text, sessionId?}]`

The `preset` on a roster row is the tool composition its child was started with. The
delegator reuses a role's session only when the requested preset matches it: a session keeps
the composition it was created with, so an old row (before the role presets, or under a
different one) is re-created rather than handed a brief its tools cannot perform.

**A chat has its own board.** `chatId` is the root session of the lineage that created
the task, so a delegated child's rows land on the parent chat's board instead of its own.
Reads default to the caller's chat; the whole workspace history is still one explicit
request away (`task_list` with scope `workspace`, or the panel's **All chats** toggle).
One file with a chat column, not one file per chat: the history cannot drift out of the
ledger it belongs to, and a new chat starts empty without deleting anything. Rows written
before `chatId` existed fall back to `parentSessionId`; rows with neither are workspace
history that only the human can edit.

The `agents[]` section is the persistent role registry: one child session per role, reused by every task that fits it. A role is not a task title. The file is the durable record. It survives a Host restart, lives in the
checkout's `.dsh/` directory (gitignored), and is the same document the browser
displays. Child→task links are persisted in `$DSH_HOME/taskboard-child-links.json`,
so a `subagent/end` after a Host or plugin reload still settles the task.

## Model surface

`task_create`, `task_get`, `task_list`, `task_update` (compare-and-set on
`expectedRevision`), `task_note`, `task_link`, and the lifecycle tools
`task_pause`, `task_resume`, `task_close`, `task_remove`. The orchestrator's
`delegate_task` requires a `role` (e.g. `UX/UI`, `BACKEND`, `BUSINESS`, `RESEARCH`) and reuses
that role's existing child session; it starts a child only when the role has none. The taskboard
stores the role registry in `agents[]`. Pause/close interrupt linked children through
`ctx.subagents`; a failed interrupt is reported per child and the task stays in its previous
state (fail closed).

`task_list` takes `scope: chat` (default) or `scope: workspace`; `task_get` reads any task by
id, because knowing the id is the reason to look. A write from another chat is refused with
`other_chat` for an agent and allowed for the human, who owns the board; the refusal exists
so an id guessed or carried over from an earlier chat cannot silently rewrite work this chat
cannot see.

## Browser surface

- **Tasks** in the session header replaces the `subagent-catalog` cell. It is a
  ghost header action: the label is followed by a separate bordered count pill,
  so it reads `Tasks 4`, never a run-together `Tasks4`.
- **Tasks** icon in the sidebar panel list opens the full page. The icon inherits
  the row label color and draws no fill or border of its own; the sidebar row owns
  the selected background.
- **Board + detail**: eight status columns, a detail panel with editable title,
  status, objective, scope, non-scope, acceptance, result summary and evidence.
  The detail stacks under the board when the panel is narrower than 920px, and
  each list field shows four lines before scrolling (96px/84px textareas).
- **Back** is the leftmost top-bar action. It returns to the conversation from which the panel was opened: the header trigger captures its exact session, and the sidebar entry captures the retained main-view conversation. It is hidden when there is no originating chat.
- **Hide** lives in the task-detail header, beside the task id and title; it
  collapses the right pane and gives the board the full width. The selection is
  kept, and clicking or keyboard-selecting any card reopens the detail. There is
  no show/hide control in the top bar.
- **Scaling**: a **Board / List** switch sits in the top bar. List is the dense scan view — one row per task with status, title/objective, subagents, owner and updated time — and becomes the default when a board has more than 8 tasks. A filter row adds title/scope/owner search and a status filter; both views use the same filtered set and keep the detail pane. The kanban stays available for workflow shaped work.
- **Scope**: the filter row starts with **This chat / All chats**. This chat is the default
  and is the chat's board; All chats reads the whole workspace history in place, with
  foreign rows marked `other chat` (card chip and list column), and **Back** to This chat
  when the conversation changes. The header count, the top-bar count and the filter count
  all follow the active scope, and a chat with no tasks says how many exist elsewhere
  instead of looking broken. Switching scope drops a selection that is not in the new
  working set, so the detail pane never shows a task the visible board says is not there.
- **Wheel scrolling**: wheel input over the board is captured as one horizontal
  axis. A vertical mouse wheel, a horizontal trackpad gesture, and a diagonal
  gesture all move the board sideways; the page does not scroll vertically at
  the same time. The listener is native and non-passive. At a horizontal edge
  the board stops rather than chaining the page. Move the pointer off the board
  to scroll the page. The list view keeps normal vertical page scrolling.
- **Subagents**: the board's `agents[]` registry drives the workspace roster; a task's `children[]` entries render as role-first rows with the
  label/id, an `active`/`sleeping`/`paused` badge and an **Open** action. A
  one-line summary above the rows reads e.g.
  `2 subagents · 1 active · 1 sleeping`. The board top carries a compact
  workspace roster with total, active, sleeping (paused/linked when present) and
  every role name with its count. Card chips show the first role, `+N`, and the
  active/sleeping counts. Tasks without `children[]` fall back to
  `childSessionIds[]` with role `child` and neutral state `linked`.
- **Lifecycle**: **Pause** moves the task to `paused` and interrupts its linked
  child sessions; **Resume** moves it back to `active` (it does not auto-prompt a
  child; open the child to continue). **Close** marks it done and interrupts
  children; if the subagent service cannot be reached it refuses to mark done. **Remove** deletes the task and its timeline after a
  confirmation, and deliberately leaves child sessions running. `paused` and
  `done` are lifecycle states, not ordinary edit values: the status select
  disables those options and Save never submits them. Host refusals such as
  `use_pause`, `use_close`, `empty_title` or `interrupt_failed` are shown as
  errors.
- **Timeline**: created, edited, delegated, child started/finished, paused,
  resumed, closed, notes.
- **Child sessions**: each linked child opens its existing conversation.
- **Artifacts**: paths from the result, ready for `present` or the preview.

The browser reads the ledger through the existing `workspaceFiles.read` Remote
and writes through the existing `/taskboard` command Remote. There is no custom
Typert namespace and no second RPC layer.

## Save model

Save is kept on purpose. It is an explicit commit of one batch of fields, not a
keystroke autosave. The Host's compare-and-set (`expectedRevision`) has one
well-defined moment to succeed or return a stale conflict, so two editors cannot
interleave silently; a debounce would move that moment around without removing
the conflict. The client therefore:

- keeps the dirty hint and the disabled **Saved** state;
- disables Save for an empty title and says why;
- preserves acceptance `{text,done}` flags when the text is unchanged, and keeps
  `result.artifacts`, `result.decisions` and `result.risks` when saving
  summary/evidence;
- merges the returned task immediately, so Save visibly advances `rev`;
- treats a write without a recognizable command result as an error;
- keeps the board, selection and draft on a failed write. A background poll may
  not clear a write error; only a successful write does;
- when a poll sees a new revision while the draft is dirty, keeps the draft and
  shows a conflict banner with **Refresh** instead of discarding the edit.

The page picks a live/retained session for the selected workspace
(`retainedBy.mainView > 0` from the `useSessions` standard prop) rather than
`sessionIds[0]`. When no live session exists, the board is read-only and says
**Open a live conversation to edit this board**; Save and lifecycle actions are
disabled instead of failing silently. The header trigger still passes its exact
live session and is left alone.

## Failure behavior

- A stale save is rejected with the current revision; the client keeps the dirty
  draft and offers Refresh. A malformed ledger fails the read loudly rather than
  replacing the human's work. The Host writes temp-file + rename, so a crash
  cannot leave half a JSON document.
- A write from another chat is refused with `other_chat` for an agent; the panel
  (the human) may still fix an old row it is reading, which is why Remove on an
  earlier chat's task works from the All-chats view.
- A read stops on `eof`. If the ledger does not reach `eof` within 200 pages of
  2,000 lines, the read returns `ledger is too large to read` instead of parsing
  truncated JSON (a maximal board is about 75 pages).
- At the configured cap (default 200 tasks) a create is refused with
  `board_full`; the Host never evicts an older task as a side effect of a write.
- The ledger has no cross-process file lock. Run one DSH host per workspace;
  a second host writing the same checkout can lose an update (the UI shows the
  `session/writer-held` failure instead of pretending it saved).
